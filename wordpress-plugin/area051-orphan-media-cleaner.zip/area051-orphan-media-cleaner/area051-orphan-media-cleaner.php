<?php
/**
 * Plugin Name: Area051 Orphan Media Cleaner
 * Description: Scansiona ed elimina i media orfani (non collegati ad alcun contenuto) in sicurezza.
 * Version: 1.0.0
 * Author: Area051
 * Author URI: https://area051.com
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: area051-orphan-media-cleaner
 */

if (!defined('ABSPATH')) {
    exit;
}

class Area051_Orphan_Media_Cleaner {
    const MENU_SLUG = 'area051-orphan-media-cleaner';
    const PARENT_MENU_SLUG = 'reti-riserve-suite';
    const TRANSIENT_SCAN = 'area051_orphan_media_scan_result';
    const NONCE_SCAN = 'area051_orphan_media_scan';
    const NONCE_DELETE = 'area051_orphan_media_delete';

    public function init() {
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_post_area051_scan_orphan_media', array($this, 'handle_scan'));
        add_action('admin_post_area051_delete_orphan_media', array($this, 'handle_delete'));
    }

    public function register_admin_menu() {
        if (!isset($GLOBALS['admin_page_hooks'][self::PARENT_MENU_SLUG])) {
            add_menu_page(
                __('Reti Riserve', 'area051-orphan-media-cleaner'),
                __('Reti Riserve', 'area051-orphan-media-cleaner'),
                'manage_options',
                self::PARENT_MENU_SLUG,
                array($this, 'render_area051_hub_page'),
                'dashicons-admin-tools',
                58
            );
        }

        add_submenu_page(
            self::PARENT_MENU_SLUG,
            __('Orphan Media Cleaner', 'area051-orphan-media-cleaner'),
            __('Orphan Media Cleaner', 'area051-orphan-media-cleaner'),
            'manage_options',
            self::MENU_SLUG,
            array($this, 'render_admin_page')
        );
    }

    public function render_area051_hub_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Reti Riserve', 'area051-orphan-media-cleaner') . '</h1>';
        echo '<p>' . esc_html__('Suite strumenti utili per il passaggio da Drupal a WordPress.', 'area051-orphan-media-cleaner') . '</p>';
        echo '<ul style="list-style:disc;padding-left:20px;max-width:900px;">';
        echo '<li><strong>' . esc_html__('Site JSON Importer', 'area051-orphan-media-cleaner') . '</strong>: '
            . esc_html__('importa contenuti da endpoint Drupal JSON verso WordPress con mapping campi, immagini, tassonomie e parent linking.', 'area051-orphan-media-cleaner')
            . '</li>';
        echo '<li><strong>' . esc_html__('Orphan Media Cleaner', 'area051-orphan-media-cleaner') . '</strong>: '
            . esc_html__('aiuta a ripulire i media orfani dopo migrazioni/reimport, liberando spazio su hosting.', 'area051-orphan-media-cleaner')
            . '</li>';
        echo '</ul>';
        echo '</div>';
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $scan_result = get_transient(self::TRANSIENT_SCAN);
        if (!is_array($scan_result)) {
            $scan_result = array(
                'scanned' => 0,
                'orphans' => array(),
                'generated_at' => 0,
            );
        }

        $notice = isset($_GET['a51_notice']) ? sanitize_key(wp_unslash($_GET['a51_notice'])) : '';
        $deleted_count = isset($_GET['deleted']) ? absint($_GET['deleted']) : 0;

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Area051 Orphan Media Cleaner', 'area051-orphan-media-cleaner') . '</h1>';

        if ($notice === 'scan_done') {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html(sprintf(__('Scansione completata. Allegati controllati: %d. Orfani trovati: %d.', 'area051-orphan-media-cleaner'), (int) $scan_result['scanned'], count($scan_result['orphans'])))
                . '</p></div>';
        } elseif ($notice === 'delete_done') {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html(sprintf(__('Eliminazione completata. Media eliminati: %d.', 'area051-orphan-media-cleaner'), $deleted_count))
                . '</p></div>';
        }

        echo '<p>' . esc_html__('Definizione usata: allegato non collegato a un post parent, non usato come immagine in evidenza, non referenziato in meta/options principali e non presente nel contenuto dei post tramite URL.', 'area051-orphan-media-cleaner') . '</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:16px 0;">';
        wp_nonce_field(self::NONCE_SCAN);
        echo '<input type="hidden" name="action" value="area051_scan_orphan_media" />';
        submit_button(__('Analizza media orfani', 'area051-orphan-media-cleaner'), 'primary', 'submit', false);
        echo '</form>';

        $orphans = isset($scan_result['orphans']) && is_array($scan_result['orphans']) ? $scan_result['orphans'] : array();
        if (!empty($orphans)) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0 0 16px;">';
            wp_nonce_field(self::NONCE_DELETE);
            echo '<input type="hidden" name="action" value="area051_delete_orphan_media" />';
            submit_button(__('Elimina tutti gli orfani trovati', 'area051-orphan-media-cleaner'), 'delete', 'submit', false, array(
                'onclick' => "return confirm('Confermi eliminazione definitiva dei media orfani trovati?');",
            ));
            echo '</form>';
        }

        $generated_at = !empty($scan_result['generated_at']) ? (int) $scan_result['generated_at'] : 0;
        echo '<p><strong>' . esc_html__('Ultima scansione:', 'area051-orphan-media-cleaner') . '</strong> ';
        echo $generated_at > 0 ? esc_html(wp_date('Y-m-d H:i:s', $generated_at)) : esc_html__('mai', 'area051-orphan-media-cleaner');
        echo '</p>';

        echo '<p><strong>' . esc_html__('Orfani trovati:', 'area051-orphan-media-cleaner') . '</strong> ' . esc_html((string) count($orphans)) . '</p>';

        if (!empty($orphans)) {
            echo '<table class="widefat striped" style="max-width:1100px">';
            echo '<thead><tr><th>ID</th><th>' . esc_html__('Titolo', 'area051-orphan-media-cleaner') . '</th><th>URL</th></tr></thead><tbody>';
            $preview_ids = array_slice($orphans, 0, 100);
            foreach ($preview_ids as $attachment_id) {
                $attachment_id = (int) $attachment_id;
                $title = get_the_title($attachment_id);
                $url = wp_get_attachment_url($attachment_id);
                echo '<tr>';
                echo '<td>' . esc_html((string) $attachment_id) . '</td>';
                echo '<td>' . esc_html($title ? $title : '-') . '</td>';
                echo '<td>' . ($url ? '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($url) . '</a>' : '-') . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            if (count($orphans) > 100) {
                echo '<p><em>' . esc_html__('Anteprima limitata ai primi 100 risultati.', 'area051-orphan-media-cleaner') . '</em></p>';
            }
        }

        echo '</div>';
    }

    public function handle_scan() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'area051-orphan-media-cleaner'));
        }

        check_admin_referer(self::NONCE_SCAN);

        $attachment_ids = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'orderby' => 'ID',
            'order' => 'ASC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ));

        if (!is_array($attachment_ids)) {
            $attachment_ids = array();
        }

        $orphans = array();
        foreach ($attachment_ids as $attachment_id) {
            $attachment_id = (int) $attachment_id;
            if ($attachment_id <= 0) {
                continue;
            }

            if ($this->is_orphan_attachment($attachment_id)) {
                $orphans[] = $attachment_id;
            }
        }

        set_transient(self::TRANSIENT_SCAN, array(
            'scanned' => count($attachment_ids),
            'orphans' => array_values(array_unique($orphans)),
            'generated_at' => time(),
        ), HOUR_IN_SECONDS * 6);

        $redirect = add_query_arg(array(
            'page' => self::MENU_SLUG,
            'a51_notice' => 'scan_done',
        ), admin_url('admin.php'));

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_delete() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'area051-orphan-media-cleaner'));
        }

        check_admin_referer(self::NONCE_DELETE);

        $scan_result = get_transient(self::TRANSIENT_SCAN);
        $orphans = is_array($scan_result) && isset($scan_result['orphans']) && is_array($scan_result['orphans'])
            ? $scan_result['orphans']
            : array();

        $deleted = 0;
        foreach ($orphans as $attachment_id) {
            $attachment_id = (int) $attachment_id;
            if ($attachment_id <= 0) {
                continue;
            }

            $result = wp_delete_attachment($attachment_id, true);
            if ($result) {
                $deleted++;
            }
        }

        delete_transient(self::TRANSIENT_SCAN);

        $redirect = add_query_arg(array(
            'page' => self::MENU_SLUG,
            'a51_notice' => 'delete_done',
            'deleted' => $deleted,
        ), admin_url('admin.php'));

        wp_safe_redirect($redirect);
        exit;
    }

    protected function is_orphan_attachment($attachment_id) {
        if ((int) get_post_field('post_parent', $attachment_id) > 0) {
            return false;
        }

        if ((int) get_option('site_icon') === (int) $attachment_id) {
            return false;
        }

        if ((int) get_theme_mod('custom_logo') === (int) $attachment_id) {
            return false;
        }

        if ($this->is_used_as_featured_image($attachment_id)) {
            return false;
        }

        if ($this->is_used_in_postmeta($attachment_id)) {
            return false;
        }

        $url = wp_get_attachment_url($attachment_id);
        if (is_string($url) && $url !== '' && $this->is_used_in_post_content($url)) {
            return false;
        }

        return true;
    }

    protected function is_used_as_featured_image($attachment_id) {
        global $wpdb;

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %s LIMIT 1",
            (string) (int) $attachment_id
        ));

        return !empty($found);
    }

    protected function is_used_in_postmeta($attachment_id) {
        global $wpdb;

        $id = (int) $attachment_id;
        $needle_exact = (string) $id;
        $needle_serialized_int = '%i:' . $id . ';%';
        $needle_serialized_string = '%:"' . $id . '";%';

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta}
             WHERE meta_key != '_thumbnail_id'
               AND (meta_value = %s OR meta_value LIKE %s OR meta_value LIKE %s)
             LIMIT 1",
            $needle_exact,
            $needle_serialized_int,
            $needle_serialized_string
        ));

        return !empty($found);
    }

    protected function is_used_in_post_content($attachment_url) {
        global $wpdb;

        $like = '%' . $wpdb->esc_like($attachment_url) . '%';
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type != 'attachment' AND post_content LIKE %s
             LIMIT 1",
            $like
        ));

        return !empty($found);
    }
}

function area051_orphan_media_cleaner_bootstrap() {
    $plugin = new Area051_Orphan_Media_Cleaner();
    $plugin->init();
}

area051_orphan_media_cleaner_bootstrap();
