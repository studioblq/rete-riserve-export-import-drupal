<?php

if (!defined('ABSPATH')) {
    exit;
}

class RRS_Shortcodes {

    public function init() {
        add_shortcode('categorie_prodotti', array($this, 'shortcode_categorie_prodotti'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
    }

    public function enqueue_styles() {
        wp_register_style('rrs-shortcodes', false, array(), '1.0.0');
        wp_enqueue_style('rrs-shortcodes');

        wp_add_inline_style('rrs-shortcodes', '
            .rrs-cat-menu {
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .rrs-cat-menu--horizontal {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
            }
            .rrs-cat-menu--vertical {
                display: flex;
                flex-direction: column;
                gap: 4px;
            }
            .rrs-cat-menu__item a {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                text-decoration: none;
            }
            .rrs-cat-menu--horizontal .rrs-cat-menu__item a {
                padding: 6px 14px;
                border: 1px solid currentColor;
                border-radius: 4px;
            }
            .rrs-cat-menu__count {
                font-size: 0.85em;
                opacity: 0.7;
            }
        ');
    }

    /**
     * [categorie_prodotti layout="vertical|horizontal" conteggio="true|false" profondita="1" genitore="0"]
     */
    public function shortcode_categorie_prodotti($atts) {
        if (!class_exists('WooCommerce')) {
            return '<p>' . esc_html__('WooCommerce non è attivo.', 'reti-riserve-shortcodes') . '</p>';
        }

        $atts = shortcode_atts(array(
            'layout'     => 'vertical',   // vertical | horizontal
            'conteggio'  => 'true',        // mostra numero prodotti
            'profondita' => 1,             // livelli di profondità (1 = solo top-level)
            'genitore'   => 0,             // ID categoria genitore (0 = radice)
            'vuote'      => 'false',       // includi categorie senza prodotti
            'classe'     => '',            // classe CSS aggiuntiva
        ), $atts, 'categorie_prodotti');

        $show_count  = filter_var($atts['conteggio'], FILTER_VALIDATE_BOOLEAN);
        $hide_empty  = !filter_var($atts['vuote'], FILTER_VALIDATE_BOOLEAN);
        $depth       = max(1, intval($atts['profondita']));
        $parent_id   = intval($atts['genitore']);
        $layout      = in_array($atts['layout'], array('horizontal', 'vertical'), true) ? $atts['layout'] : 'vertical';
        $extra_class = sanitize_html_class($atts['classe']);

        $terms = get_terms(array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => $hide_empty,
            'parent'     => $parent_id,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ));

        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }

        $css_class = trim('rrs-cat-menu rrs-cat-menu--' . $layout . ' ' . $extra_class);

        return '<ul class="' . esc_attr($css_class) . '">'
            . $this->render_category_items($terms, $show_count, $depth, $hide_empty, $layout)
            . '</ul>';
    }

    protected function render_category_items($terms, $show_count, $depth, $hide_empty, $layout, $current_depth = 1) {
        $output = '';

        foreach ($terms as $term) {
            $link  = get_term_link($term, 'product_cat');
            $count = '';

            if ($show_count) {
                $count = ' <span class="rrs-cat-menu__count">(' . intval($term->count) . ')</span>';
            }

            $output .= '<li class="rrs-cat-menu__item">';
            $output .= '<a href="' . esc_url($link) . '">' . esc_html($term->name) . $count . '</a>';

            if ($depth > $current_depth) {
                $children = get_terms(array(
                    'taxonomy'   => 'product_cat',
                    'hide_empty' => $hide_empty,
                    'parent'     => $term->term_id,
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                ));

                if (!is_wp_error($children) && !empty($children)) {
                    $child_class = 'rrs-cat-menu rrs-cat-menu--' . $layout . ' rrs-cat-menu--child';
                    $output .= '<ul class="' . esc_attr($child_class) . '">'
                        . $this->render_category_items($children, $show_count, $depth, $hide_empty, $layout, $current_depth + 1)
                        . '</ul>';
                }
            }

            $output .= '</li>';
        }

        return $output;
    }
}
