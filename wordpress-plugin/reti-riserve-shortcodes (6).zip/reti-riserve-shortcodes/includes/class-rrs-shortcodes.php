<?php

if (!defined('ABSPATH')) {
    exit;
}

class RRS_Shortcodes {

    const PARENT_MENU_SLUG = 'reti-riserve-suite';
    const MENU_SLUG        = 'rrs-shortcodes';

    public function init() {
        add_shortcode('categorie_prodotti', array($this, 'shortcode_categorie_prodotti'));
        add_shortcode('griglia_prodotti',    array($this, 'shortcode_griglia_prodotti'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('admin_menu', array($this, 'register_admin_menu'));
    }

    public function register_admin_menu() {
        // Crea il menu padre solo se nessun altro plugin lo ha già creato
        if (!isset($GLOBALS['admin_page_hooks'][self::PARENT_MENU_SLUG])) {
            add_menu_page(
                __('Area051 WP', 'reti-riserve-shortcodes'),
                __('Area051 WP', 'reti-riserve-shortcodes'),
                'manage_options',
                self::PARENT_MENU_SLUG,
                '__return_empty_string',
                'dashicons-admin-tools',
                58
            );
        }

        add_submenu_page(
            self::PARENT_MENU_SLUG,
            __('Shortcodes', 'reti-riserve-shortcodes'),
            __('Shortcodes', 'reti-riserve-shortcodes'),
            'manage_options',
            self::MENU_SLUG,
            array($this, 'render_admin_page')
        );
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Shortcodes disponibili', 'reti-riserve-shortcodes'); ?></h1>
            <p><?php esc_html_e('Configura i parametri e copia lo shortcode generato.', 'reti-riserve-shortcodes'); ?></p>

            <style>
                .rrs-builder { border: 1px solid #c3c4c7; border-radius: 4px; background: #fff; margin-bottom: 24px; }
                .rrs-builder__head { background: #f0f0f1; padding: 10px 16px; border-bottom: 1px solid #c3c4c7; display: flex; align-items: center; gap: 10px; }
                .rrs-builder__head h2 { margin: 0; font-size: 14px; }
                .rrs-builder__desc { color: #646970; font-size: 13px; }
                .rrs-builder__body { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
                .rrs-builder__controls { padding: 16px; border-right: 1px solid #c3c4c7; }
                .rrs-builder__preview { padding: 16px; background: #f6f7f7; display: flex; flex-direction: column; gap: 10px; }
                .rrs-builder__controls label { display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px; font-size: 13px; font-weight: 600; }
                .rrs-builder__controls label span { font-weight: 400; color: #646970; font-size: 12px; }
                .rrs-builder__controls .rrs-check-row { flex-direction: row; align-items: center; gap: 8px; font-weight: 400; }
                .rrs-builder__controls select,
                .rrs-builder__controls input[type=number] { width: 100%; max-width: 240px; }
                .rrs-shortcode-output { font-family: monospace; font-size: 13px; background: #1d2327; color: #a6e22e; padding: 12px; border-radius: 4px; word-break: break-all; min-height: 40px; }
                .rrs-copy-btn { align-self: flex-start; }
                .rrs-copy-btn.copied { background: #00a32a; border-color: #00a32a; color: #fff; }
                @media (max-width: 782px) { .rrs-builder__body { grid-template-columns: 1fr; } .rrs-builder__controls { border-right: none; border-bottom: 1px solid #c3c4c7; } }
            </style>

            <!-- ============================================================ -->
            <!-- [categorie_prodotti] -->
            <!-- ============================================================ -->
            <div class="rrs-builder" data-shortcode="categorie_prodotti">
                <div class="rrs-builder__head">
                    <h2><code>[categorie_prodotti]</code></h2>
                    <span class="rrs-builder__desc"><?php esc_html_e('Elenco categorie prodotto WooCommerce', 'reti-riserve-shortcodes'); ?></span>
                </div>
                <div class="rrs-builder__body">
                    <div class="rrs-builder__controls">

                        <label>
                            <?php esc_html_e('Layout', 'reti-riserve-shortcodes'); ?>
                            <select data-param="layout">
                                <option value="vertical"><?php esc_html_e('Verticale', 'reti-riserve-shortcodes'); ?></option>
                                <option value="horizontal"><?php esc_html_e('Orizzontale', 'reti-riserve-shortcodes'); ?></option>
                            </select>
                        </label>

                        <label class="rrs-check-row">
                            <input type="checkbox" data-param="conteggio" data-type="bool" checked>
                            <?php esc_html_e('Mostra numero prodotti per categoria', 'reti-riserve-shortcodes'); ?>
                        </label>

                        <label class="rrs-check-row">
                            <input type="checkbox" data-param="vuote" data-type="bool">
                            <?php esc_html_e('Includi categorie senza prodotti', 'reti-riserve-shortcodes'); ?>
                        </label>

                        <label class="rrs-check-row">
                            <input type="checkbox" data-param="icone" data-type="bool">
                            <?php esc_html_e('Mostra icone (Font Awesome)', 'reti-riserve-shortcodes'); ?>
                        </label>

                        <label>
                            <?php esc_html_e('Tipo icona', 'reti-riserve-shortcodes'); ?>
                            <select data-param="tipo_icone">
                                <option value="fa-folder"><?php esc_html_e('Cartella', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-tag"><?php esc_html_e('Tag', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-bookmark"><?php esc_html_e('Segnalibro', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-shopping-bag"><?php esc_html_e('Borsa shopping', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-leaf"><?php esc_html_e('Foglia', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-heart"><?php esc_html_e('Cuore', 'reti-riserve-shortcodes'); ?></option>
                                <option value="fa-star"><?php esc_html_e('Stella', 'reti-riserve-shortcodes'); ?></option>
                            </select>
                        </label>

                        <label>
                            <?php esc_html_e('Profondità (livelli)', 'reti-riserve-shortcodes'); ?>
                            <span><?php esc_html_e('1 = solo categorie radice', 'reti-riserve-shortcodes'); ?></span>
                            <input type="number" data-param="profondita" value="1" min="1" max="5">
                        </label>

                        <label>
                            <?php esc_html_e('ID categoria genitore', 'reti-riserve-shortcodes'); ?>
                            <span><?php esc_html_e('0 = tutte le radici', 'reti-riserve-shortcodes'); ?></span>
                            <input type="number" data-param="genitore" value="0" min="0">
                        </label>

                        <label>
                            <?php esc_html_e('Classe CSS aggiuntiva', 'reti-riserve-shortcodes'); ?>
                            <input type="text" data-param="classe" value="" placeholder="es. my-menu">
                        </label>

                    </div>
                    <div class="rrs-builder__preview">
                        <strong style="font-size:13px;"><?php esc_html_e('Shortcode generato:', 'reti-riserve-shortcodes'); ?></strong>
                        <div class="rrs-shortcode-output"></div>
                        <button type="button" class="button rrs-copy-btn"><?php esc_html_e('Copia', 'reti-riserve-shortcodes'); ?></button>
                    </div>
                </div>
            </div>

            <!-- ============================================================ -->
            <!-- [griglia_prodotti] -->
            <!-- ============================================================ -->
            <div class="rrs-builder" data-shortcode="griglia_prodotti">
                <div class="rrs-builder__head">
                    <h2><code>[griglia_prodotti]</code></h2>
                    <span class="rrs-builder__desc"><?php esc_html_e('Griglia prodotti WooCommerce', 'reti-riserve-shortcodes'); ?></span>
                </div>
                <div class="rrs-builder__body">
                    <div class="rrs-builder__controls">

                        <label>
                            <?php esc_html_e('Ordinamento', 'reti-riserve-shortcodes'); ?>
                            <select data-param="ordinamento">
                                <option value="piu_visti"><?php esc_html_e('Più visti', 'reti-riserve-shortcodes'); ?></option>
                                <option value="recenti"><?php esc_html_e('Più recenti', 'reti-riserve-shortcodes'); ?></option>
                                <option value="prezzo_asc"><?php esc_html_e('Prezzo crescente', 'reti-riserve-shortcodes'); ?></option>
                                <option value="prezzo_desc"><?php esc_html_e('Prezzo decrescente', 'reti-riserve-shortcodes'); ?></option>
                                <option value="nome"><?php esc_html_e('Nome A→Z', 'reti-riserve-shortcodes'); ?></option>
                                <option value="casuali"><?php esc_html_e('Casuali', 'reti-riserve-shortcodes'); ?></option>
                            </select>
                        </label>

                        <label>
                            <?php esc_html_e('Colonne per riga', 'reti-riserve-shortcodes'); ?>
                            <input type="number" data-param="colonne" value="3" min="1" max="6">
                        </label>

                        <label>
                            <?php esc_html_e('Elementi totali', 'reti-riserve-shortcodes'); ?>
                            <input type="number" data-param="elementi" value="12" min="1" max="100">
                        </label>

                        <label class="rrs-check-row">
                            <input type="checkbox" data-param="immagine" data-type="bool" checked>
                            <?php esc_html_e('Mostra immagine prodotto', 'reti-riserve-shortcodes'); ?>
                        </label>

                        <label>
                            <?php esc_html_e('Posizione immagine', 'reti-riserve-shortcodes'); ?>
                            <select data-param="posizione_immagine">
                                <option value="sopra"><?php esc_html_e('Sopra il testo', 'reti-riserve-shortcodes'); ?></option>
                                <option value="sinistra"><?php esc_html_e('A sinistra', 'reti-riserve-shortcodes'); ?></option>
                                <option value="destra"><?php esc_html_e('A destra', 'reti-riserve-shortcodes'); ?></option>
                            </select>
                        </label>

                        <label class="rrs-check-row">
                            <input type="checkbox" data-param="paginazione" data-type="bool">
                            <?php esc_html_e('Abilita paginazione', 'reti-riserve-shortcodes'); ?>
                        </label>

                        <label>
                            <?php esc_html_e('Filtra per categoria (slug)', 'reti-riserve-shortcodes'); ?>
                            <input type="text" data-param="categoria" value="" placeholder="es. abbigliamento">
                        </label>

                        <label>
                            <?php esc_html_e('Classe CSS aggiuntiva', 'reti-riserve-shortcodes'); ?>
                            <input type="text" data-param="classe" value="" placeholder="es. my-grid">
                        </label>

                    </div>
                    <div class="rrs-builder__preview">
                        <strong style="font-size:13px;"><?php esc_html_e('Shortcode generato:', 'reti-riserve-shortcodes'); ?></strong>
                        <div class="rrs-shortcode-output"></div>
                        <button type="button" class="button rrs-copy-btn"><?php esc_html_e('Copia', 'reti-riserve-shortcodes'); ?></button>
                    </div>
                </div>
            </div>

        </div>

        <script>
        (function(){
            // Defaults: parametri con valori di default che NON vanno emessi nello shortcode
            var DEFAULTS = {
                griglia_prodotti: {
                    ordinamento:        'piu_visti',
                    colonne:            '3',
                    elementi:           '12',
                    immagine:           'true',
                    posizione_immagine: 'sopra',
                    paginazione:        'false',
                    categoria:          '',
                    classe:             ''
                },
                categorie_prodotti: {
                    layout:        'vertical',
                    conteggio:     'true',
                    vuote:         'false',
                    icone:         'false',
                    tipo_icone:    'fa-folder',
                    profondita:    '1',
                    genitore:      '0',
                    classe:        ''
                }
            };

            function buildShortcode(tag, params) {
                var defaults = DEFAULTS[tag] || {};
                var attrs = '';
                Object.keys(params).forEach(function(key){
                    var val = params[key];
                    // Ometti il parametro se coincide con il default
                    if (val === defaults[key] || val === '') { return; }
                    attrs += ' ' + key + '="' + val + '"';
                });
                return '[' + tag + attrs + ']';
            }

            function collectParams(builder) {
                var params = {};
                builder.querySelectorAll('[data-param]').forEach(function(el){
                    var key  = el.getAttribute('data-param');
                    var type = el.getAttribute('data-type');
                    if (el.type === 'checkbox') {
                        params[key] = el.checked ? 'true' : 'false';
                    } else {
                        params[key] = el.value.trim();
                    }
                });
                return params;
            }

            function updatePreview(builder) {
                var tag    = builder.getAttribute('data-shortcode');
                var params = collectParams(builder);
                var sc     = buildShortcode(tag, params);
                builder.querySelector('.rrs-shortcode-output').textContent = sc;
            }

            document.querySelectorAll('.rrs-builder').forEach(function(builder){
                // Aggiorna al cambio di qualsiasi controllo
                builder.querySelectorAll('[data-param]').forEach(function(el){
                    el.addEventListener('change', function(){ updatePreview(builder); });
                    el.addEventListener('input',  function(){ updatePreview(builder); });
                });

                // Pulsante copia
                builder.querySelector('.rrs-copy-btn').addEventListener('click', function(){
                    var btn  = this;
                    var text = builder.querySelector('.rrs-shortcode-output').textContent;
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(text);
                    } else {
                        var ta = document.createElement('textarea');
                        ta.value = text;
                        ta.style.position = 'fixed';
                        ta.style.opacity  = '0';
                        document.body.appendChild(ta);
                        ta.select();
                        document.execCommand('copy');
                        document.body.removeChild(ta);
                    }
                    btn.textContent = '<?php echo esc_js(__('Copiato!', 'reti-riserve-shortcodes')); ?>';
                    btn.classList.add('copied');
                    setTimeout(function(){
                        btn.textContent = '<?php echo esc_js(__('Copia', 'reti-riserve-shortcodes')); ?>';
                        btn.classList.remove('copied');
                    }, 2000);
                });

                // Render iniziale
                updatePreview(builder);
            });
        })();
        </script>
        <?php
    }

    public function enqueue_styles() {
        wp_register_style('rrs-shortcodes', false, array(), '1.0.0');
        wp_enqueue_style('rrs-shortcodes');

        wp_add_inline_style('rrs-shortcodes', '
            .rrs-cat-menu {
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .rrs-cat-menu--horizontal {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
            }
            .rrs-cat-menu--vertical {
                display: flex;
                flex-direction: column;
                gap: 4px;
            }
            .rrs-cat-menu__item a {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                text-decoration: none;
            }
            .rrs-cat-menu--horizontal .rrs-cat-menu__item a {
                padding: 6px 14px;
                border: 1px solid currentColor;
                border-radius: 4px;
            }
            .rrs-cat-menu__count {
                font-size: 0.85em;
                opacity: 0.7;
            }
            .rrs-cat-menu__item a i {
                margin-right: 6px;
                opacity: 0.8;
            }
        ');

        wp_add_inline_style('rrs-shortcodes', '
            .rrs-product-grid {
                display: grid;
                grid-template-columns: repeat(var(--rrs-cols, 3), 1fr);
                gap: 20px;
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .rrs-product-grid__item {
                display: flex;
                flex-direction: column;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                overflow: hidden;
                background: #fff;
            }
            .rrs-product-grid__img {
                width: 100%;
                aspect-ratio: 4/3;
                object-fit: cover;
                display: block;
            }
            .rrs-product-grid__img-placeholder {
                width: 100%;
                aspect-ratio: 4/3;
                background: #f0f0f1;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #aaa;
                font-size: 12px;
            }
            .rrs-product-grid__body {
                padding: 12px;
                display: flex;
                flex-direction: column;
                gap: 6px;
                flex: 1;
            }
            .rrs-product-grid__title { font-weight: 600; font-size: 14px; line-height: 1.3; }
            .rrs-product-grid__title a { text-decoration: none; color: inherit; }
            .rrs-product-grid__price { font-size: 13px; color: #555; margin-top: auto; }
            .rrs-product-grid__pagination { margin-top: 20px; text-align: center; }
            .rrs-product-grid__pagination .page-numbers {
                display: inline-block;
                padding: 4px 10px;
                border: 1px solid #c3c4c7;
                border-radius: 3px;
                margin: 0 2px;
                text-decoration: none;
            }
            .rrs-product-grid__pagination .page-numbers.current {
                background: #2271b1;
                color: #fff;
                border-color: #2271b1;
            }
            @media (max-width: 600px) { .rrs-product-grid { --rrs-cols: 1 !important; } }
            .rrs-product-grid__item--sinistra,
            .rrs-product-grid__item--destra {
                flex-direction: row;
                align-items: flex-start;
            }
            .rrs-product-grid__item--sinistra .rrs-product-grid__img,
            .rrs-product-grid__item--destra   .rrs-product-grid__img,
            .rrs-product-grid__item--sinistra .rrs-product-grid__img-placeholder,
            .rrs-product-grid__item--destra   .rrs-product-grid__img-placeholder {
                width: 40%;
                flex-shrink: 0;
                aspect-ratio: 1/1;
            }
            .rrs-product-grid__item--sinistra .rrs-product-grid__body,
            .rrs-product-grid__item--destra   .rrs-product-grid__body { flex: 1; }
            @media (max-width: 480px) {
                .rrs-product-grid__item--sinistra,
                .rrs-product-grid__item--destra { flex-direction: column; }
                .rrs-product-grid__item--sinistra .rrs-product-grid__img,
                .rrs-product-grid__item--destra   .rrs-product-grid__img { width: 100%; }
            }
        ');
    }

    /**
     * [griglia_prodotti colonne="3" elementi="12" ordinamento="piu_visti" immagine="true" posizione_immagine="sopra" paginazione="false" categoria="" classe=""]
     */
    public function shortcode_griglia_prodotti($atts) {
        if (!class_exists('WooCommerce')) {
            return '<p>' . esc_html__('WooCommerce non è attivo.', 'reti-riserve-shortcodes') . '</p>';
        }

        $atts = shortcode_atts(array(
            'ordinamento'        => 'piu_visti',
            'colonne'            => 3,
            'elementi'           => 12,
            'immagine'           => 'true',
            'posizione_immagine' => 'sopra',
            'paginazione'        => 'false',
            'categoria'          => '',
            'classe'             => '',
        ), $atts, 'griglia_prodotti');

        $show_image  = filter_var($atts['immagine'],    FILTER_VALIDATE_BOOLEAN);
        $pagination  = filter_var($atts['paginazione'], FILTER_VALIDATE_BOOLEAN);
        $colonne     = max(1, min(6, intval($atts['colonne'])));
        $elementi    = max(1, min(100, intval($atts['elementi'])));
        $categoria   = sanitize_text_field($atts['categoria']);
        $extra_class = sanitize_html_class($atts['classe']);
        $posizione   = in_array($atts['posizione_immagine'], array('sopra', 'sinistra', 'destra'), true)
                        ? $atts['posizione_immagine'] : 'sopra';

        $paged = $pagination ? max(1, get_query_var('paged', 1)) : 1;

        $order_map = array(
            'piu_visti'   => array('orderby' => 'meta_value_num', 'meta_key' => 'total_sales', 'order' => 'DESC'),
            'recenti'     => array('orderby' => 'date',                                         'order' => 'DESC'),
            'prezzo_asc'  => array('orderby' => 'meta_value_num', 'meta_key' => '_price',       'order' => 'ASC'),
            'prezzo_desc' => array('orderby' => 'meta_value_num', 'meta_key' => '_price',       'order' => 'DESC'),
            'nome'        => array('orderby' => 'title',                                        'order' => 'ASC'),
            'casuali'     => array('orderby' => 'rand'),
        );
        $ord_key  = isset($order_map[$atts['ordinamento']]) ? $atts['ordinamento'] : 'piu_visti';
        $ord_args = $order_map[$ord_key];

        $query_args = array_merge(
            array(
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => $elementi,
                'paged'          => $paged,
            ),
            $ord_args
        );

        if ($categoria !== '') {
            $query_args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'slug',
                    'terms'    => $categoria,
                ),
            );
        }

        $query = new WP_Query($query_args);

        if (!$query->have_posts()) {
            return '';
        }

        $css_class  = trim('rrs-product-grid ' . $extra_class);
        $item_class = 'rrs-product-grid__item rrs-product-grid__item--' . $posizione;
        $output     = '<ul class="' . esc_attr($css_class) . '" style="--rrs-cols:' . $colonne . '">';

        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            if (!$product) {
                continue;
            }

            // Con immagine a destra: testo prima, poi immagine
            $text_block = '<div class="rrs-product-grid__body">'
                . '<div class="rrs-product-grid__title"><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></div>'
                . '<div class="rrs-product-grid__price">' . wp_kses_post($product->get_price_html()) . '</div>'
                . '</div>';

            $img_block = '';
            if ($show_image) {
                $thumb = get_the_post_thumbnail(get_the_ID(), 'medium', array(
                    'class' => 'rrs-product-grid__img',
                    'alt'   => esc_attr(get_the_title()),
                ));
                $img_block = $thumb
                    ? $thumb
                    : '<div class="rrs-product-grid__img-placeholder">' . esc_html__('Nessuna immagine', 'reti-riserve-shortcodes') . '</div>';
            }

            $output .= '<li class="' . esc_attr($item_class) . '">';
            if ($posizione === 'destra') {
                $output .= $text_block . $img_block;
            } else {
                $output .= $img_block . $text_block;
            }
            $output .= '</li>';
        }

        wp_reset_postdata();

        $output .= '</ul>';

        if ($pagination && $query->max_num_pages > 1) {
            $output .= '<div class="rrs-product-grid__pagination">';
            $output .= paginate_links(array(
                'total'   => $query->max_num_pages,
                'current' => $paged,
            ));
            $output .= '</div>';
        }

        return $output;
    }

    /**
     * [categorie_prodotti layout="vertical|horizontal" conteggio="true|false" profondita="1" genitore="0"]
     */
    public function shortcode_categorie_prodotti($atts) {
        if (!class_exists('WooCommerce')) {
            return '<p>' . esc_html__('WooCommerce non è attivo.', 'reti-riserve-shortcodes') . '</p>';
        }

        $atts = shortcode_atts(array(
            'layout'        => 'vertical',   // vertical | horizontal
            'conteggio'     => 'true',        // mostra numero prodotti
            'vuote'         => 'false',       // includi categorie senza prodotti
            'icone'         => 'false',       // mostra icone
            'tipo_icone'    => 'fa-folder',   // classe icona Font Awesome
            'profondita'    => 1,             // livelli di profondità (1 = solo top-level)
            'genitore'      => 0,             // ID categoria genitore (0 = radice)
            'classe'        => '',            // classe CSS aggiuntiva
        ), $atts, 'categorie_prodotti');

        $show_count  = filter_var($atts['conteggio'], FILTER_VALIDATE_BOOLEAN);
        $show_icons  = filter_var($atts['icone'], FILTER_VALIDATE_BOOLEAN);
        $hide_empty  = !filter_var($atts['vuote'], FILTER_VALIDATE_BOOLEAN);
        $depth       = max(1, intval($atts['profondita']));
        $parent_id   = intval($atts['genitore']);
        $layout      = in_array($atts['layout'], array('horizontal', 'vertical'), true) ? $atts['layout'] : 'vertical';
        $icon_class  = sanitize_html_class($atts['tipo_icone']);
        $extra_class = sanitize_html_class($atts['classe']);

        $terms = get_terms(array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => $hide_empty,
            'parent'     => $parent_id,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ));

        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }

        $css_class = trim('rrs-cat-menu rrs-cat-menu--' . $layout . ' ' . $extra_class);

        return '<ul class="' . esc_attr($css_class) . '">'
            . $this->render_category_items($terms, $show_count, $show_icons, $icon_class, $depth, $hide_empty, $layout)
            . '</ul>';
    }

    protected function render_category_items($terms, $show_count, $show_icons, $icon_class, $depth, $hide_empty, $layout, $current_depth = 1) {
        $output = '';

        foreach ($terms as $term) {
            $link  = get_term_link($term, 'product_cat');
            $count = '';
            $icon  = '';

            if ($show_count) {
                $count = ' <span class="rrs-cat-menu__count">(' . intval($term->count) . ')</span>';
            }

            if ($show_icons) {
                $icon = '<i class="fa ' . esc_attr($icon_class) . '" aria-hidden="true"></i> ';
            }

            $output .= '<li class="rrs-cat-menu__item">';
            $output .= '<a href="' . esc_url($link) . '">' . $icon . esc_html($term->name) . $count . '</a>';

            if ($depth > $current_depth) {
                $children = get_terms(array(
                    'taxonomy'   => 'product_cat',
                    'hide_empty' => $hide_empty,
                    'parent'     => $term->term_id,
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                ));

                if (!is_wp_error($children) && !empty($children)) {
                    $child_class = 'rrs-cat-menu rrs-cat-menu--' . $layout . ' rrs-cat-menu--child';
                    $output .= '<ul class="' . esc_attr($child_class) . '">'
                        . $this->render_category_items($children, $show_count, $show_icons, $icon_class, $depth, $hide_empty, $layout, $current_depth + 1)
                        . '</ul>';
                }
            }

            $output .= '</li>';
        }

        return $output;
    }
}
