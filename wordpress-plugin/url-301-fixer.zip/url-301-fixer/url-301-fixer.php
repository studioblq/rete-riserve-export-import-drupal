<?php
/**
 * Plugin Name: URL 301 Fixer
 * Description: Search and replace old URLs in WordPress content and meta, with per-page and bulk actions.
 * Version: 1.0.0
 * Author: Custom
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: url-301-fixer
 */

if (!defined('ABSPATH')) {
    exit;
}

class URL301Fixer {
    const MENU_SLUG = 'url-301-fixer';
    const CAPABILITY = 'manage_options';

    const NONCE_SEARCH = 'url301f_search';
    const NONCE_REPLACE_SELECTED = 'url301f_replace_selected';
    const NONCE_REPLACE_ALL = 'url301f_replace_all';

    const TRANSIENT_PREFIX = 'url301f_results_';

    public function init() {
        add_action('admin_menu', array($this, 'register_admin_page'));
        add_action('admin_post_url301f_search', array($this, 'handle_search'));
        add_action('admin_post_url301f_replace_selected', array($this, 'handle_replace_selected'));
        add_action('admin_post_url301f_replace_all', array($this, 'handle_replace_all'));
    }

    public function register_admin_page() {
        add_management_page(
            __('URL 301 Fixer', 'url-301-fixer'),
            __('URL 301 Fixer', 'url-301-fixer'),
            self::CAPABILITY,
            self::MENU_SLUG,
            array($this, 'render_admin_page')
        );
    }

    public function render_admin_page() {
        if (!current_user_can(self::CAPABILITY)) {
            return;
        }

        $notice = isset($_GET['url301f_notice']) ? sanitize_key(wp_unslash($_GET['url301f_notice'])) : '';
        $token = isset($_GET['url301f_token']) ? sanitize_key(wp_unslash($_GET['url301f_token'])) : '';
        $search_data = $this->get_search_data($token);

        $old_url = isset($search_data['old_url']) ? (string) $search_data['old_url'] : '';
        $new_url = isset($search_data['new_url']) ? (string) $search_data['new_url'] : '';
        $results = isset($search_data['results']) && is_array($search_data['results']) ? $search_data['results'] : array();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('URL 301 Fixer', 'url-301-fixer') . '</h1>';
        echo '<p>' . esc_html__('Insert old URL and replacement URL. First search, then replace on one page or in bulk on all matched pages.', 'url-301-fixer') . '</p>';

        if ($notice === 'search_done') {
            $pages = count($results);
            $occurrences = $this->count_total_occurrences($results);
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html(sprintf(__('Found %1$d pages and %2$d occurrences.', 'url-301-fixer'), $pages, $occurrences))
                . '</p></div>';
        } elseif ($notice === 'replace_done') {
            $updated = isset($_GET['updated']) ? absint($_GET['updated']) : 0;
            $occ = isset($_GET['occ']) ? absint($_GET['occ']) : 0;
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html(sprintf(__('Updated %1$d pages and replaced %2$d occurrences.', 'url-301-fixer'), $updated, $occ))
                . '</p></div>';
        } elseif ($notice === 'error') {
            $msg = isset($_GET['message']) ? sanitize_text_field(wp_unslash($_GET['message'])) : __('Unknown error.', 'url-301-fixer');
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($msg) . '</p></div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="max-width:980px;">';
        echo '<input type="hidden" name="action" value="url301f_search">';
        wp_nonce_field(self::NONCE_SEARCH, 'url301f_nonce');

        echo '<table class="form-table" role="presentation">';
        echo '<tr>';
        echo '<th scope="row"><label for="url301f-old-url">' . esc_html__('Old URL to find', 'url-301-fixer') . '</label></th>';
        echo '<td><input type="text" id="url301f-old-url" name="old_url" value="' . esc_attr($old_url) . '" class="regular-text" required></td>';
        echo '</tr>';
        echo '<tr>';
        echo '<th scope="row"><label for="url301f-new-url">' . esc_html__('New URL to use', 'url-301-fixer') . '</label></th>';
        echo '<td><input type="text" id="url301f-new-url" name="new_url" value="' . esc_attr($new_url) . '" class="regular-text"></td>';
        echo '</tr>';
        echo '</table>';

        submit_button(__('Search matches', 'url-301-fixer'), 'primary', 'submit', false);
        echo '</form>';

        if (!empty($results)) {
            $this->render_results_table($results, $old_url, $new_url, $token);
        }

        echo '</div>';
    }

    protected function render_results_table(array $results, $old_url, $new_url, $token) {
        echo '<hr>'; 
        echo '<h2>' . esc_html__('Matched pages', 'url-301-fixer') . '</h2>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="url301f_replace_selected">';
        echo '<input type="hidden" name="url301f_token" value="' . esc_attr($token) . '">';
        echo '<input type="hidden" name="old_url" value="' . esc_attr($old_url) . '">';
        echo '<input type="hidden" name="new_url" value="' . esc_attr($new_url) . '">';
        wp_nonce_field(self::NONCE_REPLACE_SELECTED, 'url301f_nonce');

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<td class="manage-column column-cb check-column"><input type="checkbox" id="url301f-check-all"></td>';
        echo '<th>' . esc_html__('Title', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Type', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Status', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Permalink', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Content matches', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Meta matches', 'url-301-fixer') . '</th>';
        echo '<th>' . esc_html__('Total', 'url-301-fixer') . '</th>';
        echo '</tr></thead>';
        echo '<tbody>';

        foreach ($results as $post_id => $row) {
            $title = get_the_title($post_id);
            if ($title === '') {
                $title = __('(no title)', 'url-301-fixer');
            }

            $permalink = get_permalink($post_id);
            $type_obj = get_post_type_object($row['post_type']);
            $type_label = $type_obj ? $type_obj->labels->singular_name : $row['post_type'];

            echo '<tr>';
            echo '<th scope="row" class="check-column"><input type="checkbox" name="selected_posts[]" value="' . esc_attr($post_id) . '"></th>';
            echo '<td><strong>' . esc_html($title) . '</strong><br><span style="color:#646970;">ID: ' . esc_html((string) $post_id) . '</span></td>';
            echo '<td>' . esc_html($type_label) . '</td>';
            echo '<td>' . esc_html($row['post_status']) . '</td>';
            echo '<td>';
            if (!empty($permalink)) {
                echo '<a href="' . esc_url($permalink) . '" target="_blank" rel="noopener noreferrer">' . esc_html($permalink) . '</a>';
            } else {
                echo '&mdash;';
            }
            echo '</td>';
            echo '<td>' . esc_html((string) $row['content_matches']) . '</td>';
            echo '<td>' . esc_html((string) $row['meta_matches']) . '</td>';
            echo '<td><strong>' . esc_html((string) $row['total_matches']) . '</strong></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        echo '<p style="margin-top:12px;">';
        submit_button(__('Replace on selected pages', 'url-301-fixer'), 'primary', 'submit', false);
        echo '</p>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(' . wp_json_encode(__('Confirm replace on all found pages?', 'url-301-fixer')) . ');">';
        echo '<input type="hidden" name="action" value="url301f_replace_all">';
        echo '<input type="hidden" name="url301f_token" value="' . esc_attr($token) . '">';
        echo '<input type="hidden" name="old_url" value="' . esc_attr($old_url) . '">';
        echo '<input type="hidden" name="new_url" value="' . esc_attr($new_url) . '">';
        wp_nonce_field(self::NONCE_REPLACE_ALL, 'url301f_nonce');
        submit_button(__('Replace on all found pages', 'url-301-fixer'), 'secondary', 'submit', false);
        echo '</form>';

        echo '<script>(function(){var checkAll=document.getElementById("url301f-check-all");if(!checkAll){return;}checkAll.addEventListener("change",function(){var boxes=document.querySelectorAll("input[name=\"selected_posts[]\"]");for(var i=0;i<boxes.length;i++){boxes[i].checked=checkAll.checked;}});})();</script>';
    }

    public function handle_search() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Not allowed.', 'url-301-fixer'));
        }

        check_admin_referer(self::NONCE_SEARCH, 'url301f_nonce');

        $old_url = isset($_POST['old_url']) ? trim(sanitize_text_field(wp_unslash($_POST['old_url']))) : '';
        $new_url = isset($_POST['new_url']) ? trim(sanitize_text_field(wp_unslash($_POST['new_url']))) : '';

        if ($old_url === '') {
            $this->redirect_with_error(__('Old URL is required.', 'url-301-fixer'));
        }

        $results = $this->find_matches($old_url);
        $token = $this->store_search_data($old_url, $new_url, $results);

        $redirect = add_query_arg(
            array(
                'page' => self::MENU_SLUG,
                'url301f_notice' => 'search_done',
                'url301f_token' => $token,
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_replace_selected() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Not allowed.', 'url-301-fixer'));
        }

        check_admin_referer(self::NONCE_REPLACE_SELECTED, 'url301f_nonce');

        $token = isset($_POST['url301f_token']) ? sanitize_key(wp_unslash($_POST['url301f_token'])) : '';
        $old_url = isset($_POST['old_url']) ? trim(sanitize_text_field(wp_unslash($_POST['old_url']))) : '';
        $new_url = isset($_POST['new_url']) ? trim(sanitize_text_field(wp_unslash($_POST['new_url']))) : '';

        if ($old_url === '' || $new_url === '') {
            $this->redirect_with_error(__('Old URL and new URL are required for replacement.', 'url-301-fixer'));
        }
        if ($old_url === $new_url) {
            $this->redirect_with_error(__('New URL must be different from old URL.', 'url-301-fixer'));
        }

        $selected_posts = isset($_POST['selected_posts']) && is_array($_POST['selected_posts'])
            ? array_map('absint', wp_unslash($_POST['selected_posts']))
            : array();
        $selected_posts = array_values(array_filter($selected_posts));

        if (empty($selected_posts)) {
            $this->redirect_with_error(__('Select at least one page.', 'url-301-fixer'), $token);
        }

        $stats = $this->replace_on_posts($selected_posts, $old_url, $new_url);
        $fresh_results = $this->find_matches($old_url);
        $fresh_token = $this->store_search_data($old_url, $new_url, $fresh_results, $token);

        $redirect = add_query_arg(
            array(
                'page' => self::MENU_SLUG,
                'url301f_notice' => 'replace_done',
                'url301f_token' => $fresh_token,
                'updated' => $stats['updated_posts'],
                'occ' => $stats['replaced_occurrences'],
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_replace_all() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Not allowed.', 'url-301-fixer'));
        }

        check_admin_referer(self::NONCE_REPLACE_ALL, 'url301f_nonce');

        $token = isset($_POST['url301f_token']) ? sanitize_key(wp_unslash($_POST['url301f_token'])) : '';
        $old_url = isset($_POST['old_url']) ? trim(sanitize_text_field(wp_unslash($_POST['old_url']))) : '';
        $new_url = isset($_POST['new_url']) ? trim(sanitize_text_field(wp_unslash($_POST['new_url']))) : '';

        if ($old_url === '' || $new_url === '') {
            $this->redirect_with_error(__('Old URL and new URL are required for replacement.', 'url-301-fixer'), $token);
        }
        if ($old_url === $new_url) {
            $this->redirect_with_error(__('New URL must be different from old URL.', 'url-301-fixer'), $token);
        }

        $search_data = $this->get_search_data($token);
        $results = isset($search_data['results']) && is_array($search_data['results']) ? $search_data['results'] : array();
        $post_ids = array_map('absint', array_keys($results));
        $post_ids = array_values(array_filter($post_ids));

        if (empty($post_ids)) {
            $this->redirect_with_error(__('No pages found for bulk replacement.', 'url-301-fixer'), $token);
        }

        $stats = $this->replace_on_posts($post_ids, $old_url, $new_url);
        $fresh_results = $this->find_matches($old_url);
        $fresh_token = $this->store_search_data($old_url, $new_url, $fresh_results, $token);

        $redirect = add_query_arg(
            array(
                'page' => self::MENU_SLUG,
                'url301f_notice' => 'replace_done',
                'url301f_token' => $fresh_token,
                'updated' => $stats['updated_posts'],
                'occ' => $stats['replaced_occurrences'],
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    protected function find_matches($old_url) {
        global $wpdb;

        if ($old_url === '') {
            return array();
        }

        $like = '%' . $wpdb->esc_like($old_url) . '%';

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ID, post_type, post_status, post_content, post_excerpt FROM {$wpdb->posts}
                 WHERE post_status NOT IN ('auto-draft', 'trash')
                 AND (post_content LIKE %s OR post_excerpt LIKE %s)",
                $like,
                $like
            ),
            ARRAY_A
        );

        $results = array();

        foreach ($rows as $row) {
            $post_id = (int) $row['ID'];
            $content_matches = substr_count((string) $row['post_content'], $old_url) + substr_count((string) $row['post_excerpt'], $old_url);

            if ($content_matches <= 0) {
                continue;
            }

            $results[$post_id] = array(
                'post_type' => (string) $row['post_type'],
                'post_status' => (string) $row['post_status'],
                'content_matches' => (int) $content_matches,
                'meta_matches' => 0,
                'total_matches' => (int) $content_matches,
            );
        }

        $meta_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta}
                 WHERE meta_value LIKE %s",
                $like
            ),
            ARRAY_A
        );

        foreach ($meta_rows as $meta_row) {
            $post_id = (int) $meta_row['post_id'];
            if ($post_id <= 0) {
                continue;
            }

            $post = get_post($post_id);
            if (!$post || in_array($post->post_status, array('auto-draft', 'trash'), true)) {
                continue;
            }

            $meta_matches = $this->count_occurrences_in_mixed($meta_row['meta_value'], $old_url);
            if ($meta_matches <= 0) {
                continue;
            }

            if (!isset($results[$post_id])) {
                $results[$post_id] = array(
                    'post_type' => (string) $post->post_type,
                    'post_status' => (string) $post->post_status,
                    'content_matches' => 0,
                    'meta_matches' => 0,
                    'total_matches' => 0,
                );
            }

            $results[$post_id]['meta_matches'] += $meta_matches;
            $results[$post_id]['total_matches'] += $meta_matches;
        }

        ksort($results);
        return $results;
    }

    protected function replace_on_posts(array $post_ids, $old_url, $new_url) {
        $stats = array(
            'updated_posts' => 0,
            'replaced_occurrences' => 0,
        );

        foreach ($post_ids as $post_id) {
            $post_id = absint($post_id);
            if ($post_id <= 0) {
                continue;
            }

            $post = get_post($post_id);
            if (!$post || in_array($post->post_status, array('auto-draft', 'trash'), true)) {
                continue;
            }

            $post_changes = array();
            $post_occurrences = 0;

            $content = (string) $post->post_content;
            if ($content !== '' && strpos($content, $old_url) !== false) {
                $post_changes['post_content'] = str_replace($old_url, $new_url, $content, $count);
                $post_occurrences += (int) $count;
            }

            $excerpt = (string) $post->post_excerpt;
            if ($excerpt !== '' && strpos($excerpt, $old_url) !== false) {
                $post_changes['post_excerpt'] = str_replace($old_url, $new_url, $excerpt, $count);
                $post_occurrences += (int) $count;
            }

            if (!empty($post_changes)) {
                $post_changes['ID'] = $post_id;
                wp_update_post(wp_slash($post_changes));
            }

            $meta_occurrences = $this->replace_post_meta_values($post_id, $old_url, $new_url);
            $post_occurrences += $meta_occurrences;

            if ($post_occurrences > 0) {
                $stats['updated_posts']++;
                $stats['replaced_occurrences'] += $post_occurrences;
            }
        }

        return $stats;
    }

    protected function replace_post_meta_values($post_id, $old_url, $new_url) {
        global $wpdb;

        $total = 0;

        $meta_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT meta_id, meta_key, meta_value FROM {$wpdb->postmeta}
                 WHERE post_id = %d AND meta_value LIKE %s",
                $post_id,
                '%' . $wpdb->esc_like($old_url) . '%'
            ),
            ARRAY_A
        );

        foreach ($meta_rows as $meta_row) {
            $meta_id = (int) $meta_row['meta_id'];
            if ($meta_id <= 0) {
                continue;
            }

            $raw_value = $meta_row['meta_value'];
            $parsed = maybe_unserialize($raw_value);

            $count = 0;
            $replaced = $this->replace_occurrences_in_mixed($parsed, $old_url, $new_url, $count);

            if ($count > 0) {
                update_metadata_by_mid('post', $meta_id, $replaced);
                $total += $count;
            }
        }

        return $total;
    }

    protected function replace_occurrences_in_mixed($value, $old_url, $new_url, &$count) {
        if (is_string($value)) {
            if ($value === '' || strpos($value, $old_url) === false) {
                return $value;
            }
            $count_here = 0;
            $replaced = str_replace($old_url, $new_url, $value, $count_here);
            $count += $count_here;
            return $replaced;
        }

        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $sub_count = 0;
                $value[$k] = $this->replace_occurrences_in_mixed($v, $old_url, $new_url, $sub_count);
                $count += $sub_count;
            }
            return $value;
        }

        if (is_object($value)) {
            foreach ($value as $k => $v) {
                $sub_count = 0;
                $value->{$k} = $this->replace_occurrences_in_mixed($v, $old_url, $new_url, $sub_count);
                $count += $sub_count;
            }
            return $value;
        }

        return $value;
    }

    protected function count_occurrences_in_mixed($value, $needle) {
        $parsed = maybe_unserialize($value);
        return $this->count_occurrences_recursive($parsed, $needle);
    }

    protected function count_occurrences_recursive($value, $needle) {
        if (is_string($value)) {
            return substr_count($value, $needle);
        }

        if (is_array($value)) {
            $total = 0;
            foreach ($value as $item) {
                $total += $this->count_occurrences_recursive($item, $needle);
            }
            return $total;
        }

        if (is_object($value)) {
            $total = 0;
            foreach ($value as $item) {
                $total += $this->count_occurrences_recursive($item, $needle);
            }
            return $total;
        }

        return 0;
    }

    protected function count_total_occurrences(array $results) {
        $total = 0;
        foreach ($results as $row) {
            $total += isset($row['total_matches']) ? (int) $row['total_matches'] : 0;
        }
        return $total;
    }

    protected function store_search_data($old_url, $new_url, array $results, $existing_token = '') {
        $token = $existing_token !== '' ? $existing_token : wp_generate_password(12, false, false);

        $data = array(
            'old_url' => (string) $old_url,
            'new_url' => (string) $new_url,
            'results' => $results,
            'created_at' => time(),
        );

        set_transient($this->get_transient_key($token), $data, HOUR_IN_SECONDS);

        return $token;
    }

    protected function get_search_data($token) {
        if ($token === '') {
            return array();
        }

        $data = get_transient($this->get_transient_key($token));
        return is_array($data) ? $data : array();
    }

    protected function get_transient_key($token) {
        return self::TRANSIENT_PREFIX . get_current_user_id() . '_' . sanitize_key($token);
    }

    protected function redirect_with_error($message, $token = '') {
        $args = array(
            'page' => self::MENU_SLUG,
            'url301f_notice' => 'error',
            'message' => (string) $message,
        );

        if ($token !== '') {
            $args['url301f_token'] = sanitize_key($token);
        }

        $redirect = add_query_arg($args, admin_url('tools.php'));
        wp_safe_redirect($redirect);
        exit;
    }
}

function url301f_bootstrap() {
    $plugin = new URL301Fixer();
    $plugin->init();
}

url301f_bootstrap();
