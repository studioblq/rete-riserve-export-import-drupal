=== Site JSON ACF Importer ===
Contributors: custom
Tags: import, json, acf, drupal
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Importa contenuti JSON da endpoint esterno (es. Drupal) e li salva in WordPress, con mapping campi ACF Pro.

== Installazione ==
1. Copia la cartella site-json-acf-importer in wp-content/plugins/
2. Attiva il plugin da Plugin
3. Vai su Strumenti > Site JSON Importer
4. Configura URL endpoint e opzioni base
5. Esegui "Step 1: Import JSON grezzo"
6. Configura il mapping dalla UI (tipo sorgente -> post type e campi sorgente -> ACF)
7. Esegui "Step 2: Applica mapping ai contenuti importati"

== Note ==
- Se ACF Pro non e presente, i contenuti vengono comunque importati su titolo/contenuto/excerpt e metadati.
- Lo Step 1 salva anche il payload grezzo per ogni contenuto, utile per applicare/ripetere mapping senza dover reimportare dal JSON.
- Il plugin usa uuid/nid per aggiornare contenuti gia importati.
- In caso di errore HTTP 403, verifica i permessi dell'endpoint Drupal e usa, se necessario, Bearer token/User-Agent configurabili nel plugin.
- Nel mapping UI puoi scegliere destinazioni WordPress core, campi Yoast SEO e campi ACF.
