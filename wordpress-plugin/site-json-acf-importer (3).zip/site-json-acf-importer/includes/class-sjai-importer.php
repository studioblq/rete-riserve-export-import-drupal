<?php

if (!defined('ABSPATH')) {
    exit;
}

class SJAI_Importer {
    const OPTION_KEY = 'sjai_settings';
    const OPTION_SCHEMA_KEY = 'sjai_discovered_schema';

    const NONCE_ACTION_SAVE = 'sjai_save_settings';
    const NONCE_ACTION_IMPORT_RAW = 'sjai_import_raw';
    const NONCE_ACTION_SAVE_MAPPING = 'sjai_save_mapping';
    const NONCE_ACTION_APPLY_MAPPING = 'sjai_apply_mapping';

    public function init() {
        add_action('admin_menu', array($this, 'register_admin_page'));
        add_action('admin_init', array($this, 'maybe_save_settings'));
        add_action('admin_post_sjai_import_raw', array($this, 'handle_raw_import'));
        add_action('admin_post_sjai_save_mapping', array($this, 'handle_save_mapping'));
        add_action('admin_post_sjai_apply_mapping', array($this, 'handle_apply_mapping'));
    }

    public function register_admin_page() {
        add_management_page(
            __('Site JSON Importer', 'site-json-acf-importer'),
            __('Site JSON Importer', 'site-json-acf-importer'),
            'manage_options',
            'site-json-acf-importer',
            array($this, 'render_admin_page')
        );
    }

    public function maybe_save_settings() {
        if (!is_admin()) {
            return;
        }

        if (!isset($_POST['sjai_action']) || $_POST['sjai_action'] !== 'save_settings') {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_SAVE);

        $settings = $this->get_settings();
        $settings['endpoint_url'] = isset($_POST['endpoint_url']) ? esc_url_raw(trim(wp_unslash($_POST['endpoint_url']))) : '';
        $settings['default_post_type'] = isset($_POST['default_post_type']) ? sanitize_key(wp_unslash($_POST['default_post_type'])) : 'post';
        $settings['default_status'] = isset($_POST['default_status']) ? sanitize_key(wp_unslash($_POST['default_status'])) : 'draft';
        $settings['import_images'] = !empty($_POST['import_images']) ? 1 : 0;
        $settings['auth_bearer_token'] = isset($_POST['auth_bearer_token']) ? sanitize_text_field(trim(wp_unslash($_POST['auth_bearer_token']))) : '';
        $settings['request_user_agent'] = isset($_POST['request_user_agent']) ? sanitize_text_field(trim(wp_unslash($_POST['request_user_agent']))) : 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)';
        $settings['enable_parent_linking'] = !empty($_POST['enable_parent_linking']) ? 1 : 0;
        $settings['parent_source_field'] = isset($_POST['parent_source_field']) ? sanitize_key(trim(wp_unslash($_POST['parent_source_field']))) : '';
        $settings['parent_match_field'] = isset($_POST['parent_match_field']) ? sanitize_key(trim(wp_unslash($_POST['parent_match_field']))) : 'nid';

        if (!post_type_exists($settings['default_post_type'])) {
            $settings['default_post_type'] = 'post';
        }

        update_option(self::OPTION_KEY, $settings);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'settings_saved',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_raw_import() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_IMPORT_RAW);

        $result = $this->run_raw_import();
        set_transient('sjai_last_import_result_' . get_current_user_id(), $result, MINUTE_IN_SECONDS * 10);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'raw_import_done',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_save_mapping() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_SAVE_MAPPING);

        $settings = $this->get_settings();
        $post_types = get_post_types(array(), 'names');

        $raw_type_map = isset($_POST['type_map_ui']) && is_array($_POST['type_map_ui']) ? wp_unslash($_POST['type_map_ui']) : array();
        $type_map_ui = array();
        foreach ($raw_type_map as $source_type => $wp_post_type) {
            $source_key = sanitize_key($source_type);
            $target_key = sanitize_key($wp_post_type);
            if ($source_key === '') {
                continue;
            }
            if (!in_array($target_key, $post_types, true)) {
                $target_key = $settings['default_post_type'];
            }
            $type_map_ui[$source_key] = $target_key;
        }

        $raw_acf_map = isset($_POST['acf_map_ui']) && is_array($_POST['acf_map_ui']) ? wp_unslash($_POST['acf_map_ui']) : array();
        $acf_map_ui = array();
        foreach ($raw_acf_map as $source_type => $map) {
            $source_key = sanitize_key($source_type);
            if ($source_key === '' || !is_array($map)) {
                continue;
            }

            foreach ($map as $source_field => $acf_field_name) {
                $field_key = sanitize_key($source_field);
                $acf_name = sanitize_text_field($acf_field_name);
                if ($field_key === '' || $acf_name === '') {
                    continue;
                }
                if (!isset($acf_map_ui[$source_key])) {
                    $acf_map_ui[$source_key] = array();
                }
                $acf_map_ui[$source_key][$field_key] = $acf_name;
            }
        }

        $settings['type_map_ui'] = $type_map_ui;
        $settings['acf_map_ui'] = $acf_map_ui;
        update_option(self::OPTION_KEY, $settings);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'mapping_saved',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_apply_mapping() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_APPLY_MAPPING);

        $result = $this->run_apply_mapping();
        set_transient('sjai_last_mapping_result_' . get_current_user_id(), $result, MINUTE_IN_SECONDS * 10);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'mapping_applied',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();
        $post_type_objects = get_post_types(array('public' => true), 'objects');
        $statuses = array(
            'draft' => __('Bozza', 'site-json-acf-importer'),
            'publish' => __('Pubblicato', 'site-json-acf-importer'),
            'pending' => __('In attesa', 'site-json-acf-importer'),
            'private' => __('Privato', 'site-json-acf-importer'),
        );
        $schema = $this->get_discovered_schema();
        $target_options = $this->get_target_field_options();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Site JSON Importer', 'site-json-acf-importer') . '</h1>';

        $this->render_notice();

        echo '<h2>' . esc_html__('Configurazione base', 'site-json-acf-importer') . '</h2>';
        echo '<form method="post" action="">';
        wp_nonce_field(self::NONCE_ACTION_SAVE);
        echo '<input type="hidden" name="sjai_action" value="save_settings" />';

        echo '<table class="form-table" role="presentation">';

        echo '<tr>';
        echo '<th scope="row"><label for="endpoint_url">' . esc_html__('URL endpoint JSON', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="endpoint_url" id="endpoint_url" type="url" class="regular-text" value="' . esc_attr($settings['endpoint_url']) . '" placeholder="https://example.com/it/site-json-export" required />';
        echo '<p class="description">' . esc_html__('Endpoint con struttura { meta, data[] }.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="auth_bearer_token">' . esc_html__('Bearer token (opzionale)', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="auth_bearer_token" id="auth_bearer_token" type="text" class="regular-text" value="' . esc_attr($settings['auth_bearer_token']) . '" />';
        echo '<p class="description">' . esc_html__('Se valorizzato, il plugin invia header Authorization: Bearer <token>.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="request_user_agent">' . esc_html__('User-Agent richiesta', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="request_user_agent" id="request_user_agent" type="text" class="regular-text" value="' . esc_attr($settings['request_user_agent']) . '" />';
        echo '<p class="description">' . esc_html__('Utile se firewall o CDN bloccano lo user-agent di default.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="default_post_type">' . esc_html__('Post type di default', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<select name="default_post_type" id="default_post_type">';
        foreach ($post_type_objects as $post_type => $obj) {
            echo '<option value="' . esc_attr($post_type) . '" ' . selected($settings['default_post_type'], $post_type, false) . '>' . esc_html($obj->labels->singular_name) . ' (' . esc_html($post_type) . ')</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="default_status">' . esc_html__('Stato post', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<select name="default_status" id="default_status">';
        foreach ($statuses as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($settings['default_status'], $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Importa immagini', 'site-json-acf-importer') . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="import_images" value="1" ' . checked(1, $settings['import_images'], false) . ' /> ' . esc_html__('Scarica immagini remote e salva anche ALT e TITLE negli attachment.', 'site-json-acf-importer') . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Assegna parent in secondo giro', 'site-json-acf-importer') . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="enable_parent_linking" value="1" ' . checked(1, $settings['enable_parent_linking'], false) . ' /> ' . esc_html__('Se attivo, dopo l\'import il plugin esegue un secondo passaggio e valorizza post_parent.', 'site-json-acf-importer') . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="parent_source_field">' . esc_html__('Campo sorgente che contiene il parent', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="parent_source_field" id="parent_source_field" type="text" class="regular-text" value="' . esc_attr($settings['parent_source_field']) . '" placeholder="field_contenuto_padre" />';
        echo '<p class="description">' . esc_html__('Nome del campo JSON sul contenuto figlio che contiene il valore identificativo del parent.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="parent_match_field">' . esc_html__('Campo di merge per trovare il parent', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="parent_match_field" id="parent_match_field" type="text" class="regular-text" value="' . esc_attr($settings['parent_match_field']) . '" placeholder="nid / uuid / field_custom_id" />';
        echo '<p class="description">' . esc_html__('Il valore del campo parent del figlio viene confrontato con questo campo sui contenuti importati (es: nid, uuid, o un campo custom).', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';
        submit_button(__('Salva impostazioni', 'site-json-acf-importer'));
        echo '</form>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Step 1: Import JSON grezzo', 'site-json-acf-importer') . '</h2>';
        echo '<p>' . esc_html__('Importa i contenuti base (titolo, body, excerpt, metadati sorgente) e rileva automaticamente tipi/campi disponibili per il mapping UI.', 'site-json-acf-importer') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(self::NONCE_ACTION_IMPORT_RAW);
        echo '<input type="hidden" name="action" value="sjai_import_raw" />';
        submit_button(__('Esegui import JSON grezzo', 'site-json-acf-importer'), 'primary', 'submit', false);
        echo '</form>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Step 2: Mapping UI e applicazione', 'site-json-acf-importer') . '</h2>';

        if (empty($schema['types'])) {
            echo '<p><em>' . esc_html__('Nessuno schema rilevato. Esegui prima lo Step 1.', 'site-json-acf-importer') . '</em></p>';
        } else {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field(self::NONCE_ACTION_SAVE_MAPPING);
            echo '<input type="hidden" name="action" value="sjai_save_mapping" />';

            echo '<h3>' . esc_html__('Mapping tipi sorgente -> post type WordPress', 'site-json-acf-importer') . '</h3>';
            echo '<table class="widefat striped" style="max-width:1000px">';
            echo '<thead><tr><th>' . esc_html__('Tipo sorgente', 'site-json-acf-importer') . '</th><th>' . esc_html__('Post type WordPress', 'site-json-acf-importer') . '</th></tr></thead><tbody>';

            foreach ($schema['types'] as $source_type => $fields) {
                $selected_post_type = isset($settings['type_map_ui'][$source_type]) ? $settings['type_map_ui'][$source_type] : $settings['default_post_type'];
                echo '<tr>';
                echo '<td><strong>' . esc_html($source_type) . '</strong></td>';
                echo '<td><select name="type_map_ui[' . esc_attr($source_type) . ']">';
                foreach ($post_type_objects as $post_type => $obj) {
                    echo '<option value="' . esc_attr($post_type) . '" ' . selected($selected_post_type, $post_type, false) . '>' . esc_html($obj->labels->singular_name) . ' (' . esc_html($post_type) . ')</option>';
                }
                echo '</select></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            echo '<h3 style="margin-top:20px">' . esc_html__('Mapping campi sorgente -> campi destinazione', 'site-json-acf-importer') . '</h3>';
            echo '<p class="description">' . esc_html__('Per ogni campo sorgente scegli una destinazione WordPress, Yoast o ACF. Lascia vuoto per non mappare.', 'site-json-acf-importer') . '</p>';

            foreach ($schema['types'] as $source_type => $fields) {
                echo '<h4>' . esc_html(sprintf(__('Tipo: %s', 'site-json-acf-importer'), $source_type)) . '</h4>';
                echo '<table class="widefat striped" style="max-width:1000px">';
                echo '<thead><tr><th>' . esc_html__('Campo sorgente', 'site-json-acf-importer') . '</th><th>' . esc_html__('Campo destinazione', 'site-json-acf-importer') . '</th></tr></thead><tbody>';

                foreach ($fields as $field_name) {
                    $selected_acf = '';
                    if (isset($settings['acf_map_ui'][$source_type]) && isset($settings['acf_map_ui'][$source_type][$field_name])) {
                        $selected_acf = $settings['acf_map_ui'][$source_type][$field_name];
                    }

                    echo '<tr>';
                    echo '<td>' . esc_html($field_name) . '</td>';
                    echo '<td><select name="acf_map_ui[' . esc_attr($source_type) . '][' . esc_attr($field_name) . ']">';
                    echo '<option value="">' . esc_html__('Nessun mapping', 'site-json-acf-importer') . '</option>';
                    foreach ($target_options as $target_name => $target_label) {
                        echo '<option value="' . esc_attr($target_name) . '" ' . selected($selected_acf, $target_name, false) . '>' . esc_html($target_label) . '</option>';
                    }
                    echo '</select></td>';
                    echo '</tr>';
                }

                echo '</tbody></table>';
            }

            submit_button(__('Salva mapping UI', 'site-json-acf-importer'));
            echo '</form>';

            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:10px">';
            wp_nonce_field(self::NONCE_ACTION_APPLY_MAPPING);
            echo '<input type="hidden" name="action" value="sjai_apply_mapping" />';
            submit_button(__('Applica mapping ai contenuti importati', 'site-json-acf-importer'), 'secondary', 'submit', false);
            echo '</form>';
        }

        $last_result = get_transient('sjai_last_import_result_' . get_current_user_id());
        if (is_array($last_result)) {
            echo '<h3>' . esc_html__('Ultimo risultato import grezzo', 'site-json-acf-importer') . '</h3>';
            echo '<pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:1100px;overflow:auto;">' . esc_html(wp_json_encode($last_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '</pre>';
        }

        $last_mapping_result = get_transient('sjai_last_mapping_result_' . get_current_user_id());
        if (is_array($last_mapping_result)) {
            echo '<h3>' . esc_html__('Ultimo risultato applicazione mapping', 'site-json-acf-importer') . '</h3>';
            echo '<pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:1100px;overflow:auto;">' . esc_html(wp_json_encode($last_mapping_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '</pre>';
        }

        echo '</div>';
    }

    protected function render_notice() {
        if (empty($_GET['sjai_notice'])) {
            return;
        }

        $notice = sanitize_key(wp_unslash($_GET['sjai_notice']));
        if ($notice === 'settings_saved') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Impostazioni salvate.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'raw_import_done') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Step 1 completato: import JSON grezzo eseguito.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'mapping_saved') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Mapping UI salvato.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'mapping_applied') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Step 2 completato: mapping applicato ai contenuti importati.', 'site-json-acf-importer') . '</p></div>';
        }
    }

    protected function get_settings() {
        $defaults = array(
            'endpoint_url' => '',
            'default_post_type' => 'post',
            'default_status' => 'draft',
            'import_images' => 0,
            'auth_bearer_token' => '',
            'request_user_agent' => 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)',
            'enable_parent_linking' => 0,
            'parent_source_field' => '',
            'parent_match_field' => 'nid',
            'type_map_ui' => array(),
            'acf_map_ui' => array(),
        );

        $saved = get_option(self::OPTION_KEY, array());
        $settings = wp_parse_args($saved, $defaults);

        if (!is_array($settings['type_map_ui'])) {
            $settings['type_map_ui'] = array();
        }

        if (!is_array($settings['acf_map_ui'])) {
            $settings['acf_map_ui'] = array();
        }

        return $settings;
    }

    protected function get_discovered_schema() {
        $schema = get_option(self::OPTION_SCHEMA_KEY, array());
        if (!is_array($schema) || !isset($schema['types']) || !is_array($schema['types'])) {
            return array('types' => array());
        }

        foreach ($schema['types'] as $type => $fields) {
            if (!is_array($fields)) {
                unset($schema['types'][$type]);
                continue;
            }
            $fields = array_values(array_unique(array_map('sanitize_key', $fields)));
            $fields = array_values(array_filter($fields));
            sort($fields);
            $schema['types'][$type] = $fields;
        }

        return $schema;
    }

    protected function run_raw_import() {
        $settings = $this->get_settings();
        $payload = $this->fetch_endpoint_data($settings['endpoint_url']);

        if (!$payload['ok']) {
            return $payload;
        }

        $data = $payload['data'];
        $type_map = is_array($settings['type_map_ui']) ? $settings['type_map_ui'] : array();

        $created = 0;
        $updated = 0;
        $skipped = 0;
        $errors = array();
        $schema_types = array();
        $imported_post_ids = array();

        foreach ($data as $index => $item) {
            if (!is_array($item)) {
                $skipped++;
                continue;
            }

            $source_type = isset($item['type']) ? sanitize_key($item['type']) : 'unknown';
            if ($source_type === '') {
                $source_type = 'unknown';
            }

            if (!isset($schema_types[$source_type])) {
                $schema_types[$source_type] = array();
            }

            foreach ($item as $key => $value) {
                $field_key = sanitize_key($key);
                if ($field_key === '') {
                    continue;
                }
                if (!in_array($field_key, $schema_types[$source_type], true)) {
                    $schema_types[$source_type][] = $field_key;
                }
            }

            $result = $this->import_single_item($item, $settings, $type_map, array(), false);
            if ($result['status'] === 'created') {
                $created++;
                if (!empty($result['post_id'])) {
                    $imported_post_ids[] = (int) $result['post_id'];
                }
            } elseif ($result['status'] === 'updated') {
                $updated++;
                if (!empty($result['post_id'])) {
                    $imported_post_ids[] = (int) $result['post_id'];
                }
            } elseif ($result['status'] === 'skipped') {
                $skipped++;
            } else {
                $skipped++;
                $errors[] = array(
                    'index' => $index,
                    'message' => $result['message'],
                );
            }
        }

        update_option(self::OPTION_SCHEMA_KEY, array('types' => $schema_types));

        $parent_result = array(
            'enabled' => false,
            'linked' => 0,
            'skipped' => 0,
            'errors' => array(),
        );

        if (!empty($settings['enable_parent_linking'])) {
            $parent_result = $this->assign_parents_second_pass(array_values(array_unique($imported_post_ids)), $settings);
        }

        return array(
            'ok' => true,
            'mode' => 'raw_import',
            'created' => $created,
            'updated' => $updated,
            'skipped' => $skipped,
            'types_detected' => array_keys($schema_types),
            'parent_pass' => $parent_result,
            'errors' => $errors,
        );
    }

    protected function assign_parents_second_pass($post_ids, $settings) {
        $result = array(
            'enabled' => true,
            'linked' => 0,
            'skipped' => 0,
            'errors' => array(),
        );

        $source_field = isset($settings['parent_source_field']) ? sanitize_key($settings['parent_source_field']) : '';
        $match_field = isset($settings['parent_match_field']) ? sanitize_key($settings['parent_match_field']) : 'nid';

        if ($source_field === '') {
            $result['errors'][] = 'Campo sorgente parent non configurato.';
            return $result;
        }

        foreach ((array) $post_ids as $post_id) {
            $post_id = (int) $post_id;
            if ($post_id <= 0) {
                $result['skipped']++;
                continue;
            }

            $raw = get_post_meta($post_id, '_sjai_raw_item', true);
            if (!is_string($raw) || $raw === '') {
                $result['skipped']++;
                continue;
            }

            $item = json_decode($raw, true);
            if (!is_array($item) || !array_key_exists($source_field, $item)) {
                $result['skipped']++;
                continue;
            }

            $parent_reference = $this->extract_scalar_value($item[$source_field]);
            if ($parent_reference === '') {
                $result['skipped']++;
                continue;
            }

            $parent_post_id = $this->find_parent_post_id_by_merge_field($match_field, $parent_reference);
            if ($parent_post_id <= 0 || $parent_post_id === $post_id) {
                $result['skipped']++;
                continue;
            }

            $update = wp_update_post(array(
                'ID' => $post_id,
                'post_parent' => $parent_post_id,
            ), true);

            if (is_wp_error($update)) {
                $result['errors'][] = sprintf('Post %d: %s', $post_id, $update->get_error_message());
                continue;
            }

            $result['linked']++;
        }

        return $result;
    }

    protected function find_parent_post_id_by_merge_field($merge_field, $merge_value) {
        $meta_key = '';
        $meta_value = $merge_value;

        if ($merge_field === 'uuid') {
            $meta_key = '_sjai_source_uuid';
        } elseif ($merge_field === 'nid') {
            $meta_key = '_sjai_source_nid';
            $meta_value = (string) absint($merge_value);
        } else {
            $meta_key = '_sjai_src_' . sanitize_key($merge_field);
        }

        if ($meta_key === '') {
            return 0;
        }

        $posts = get_posts(array(
            'post_type' => 'any',
            'post_status' => 'any',
            'fields' => 'ids',
            'posts_per_page' => 1,
            'meta_key' => $meta_key,
            'meta_value' => $meta_value,
        ));

        if (empty($posts)) {
            return 0;
        }

        return (int) $posts[0];
    }

    protected function run_apply_mapping() {
        $settings = $this->get_settings();
        $acf_map = is_array($settings['acf_map_ui']) ? $settings['acf_map_ui'] : array();

        if (empty($acf_map)) {
            return array(
                'ok' => false,
                'message' => 'Nessun mapping UI salvato.',
            );
        }

        $posts = get_posts(array(
            'post_type' => 'any',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_key' => '_sjai_raw_item',
        ));

        $processed = 0;
        $updated = 0;
        $skipped = 0;
        $errors = array();

        foreach ($posts as $post_id) {
            $raw = get_post_meta($post_id, '_sjai_raw_item', true);
            if (!is_string($raw) || $raw === '') {
                $skipped++;
                continue;
            }

            $item = json_decode($raw, true);
            if (!is_array($item)) {
                $skipped++;
                continue;
            }

            $source_type = get_post_meta($post_id, '_sjai_source_type', true);
            $source_type = sanitize_key($source_type);
            if ($source_type === '') {
                $source_type = isset($item['type']) ? sanitize_key($item['type']) : '';
            }

            $processed++;

            if (empty($source_type) || empty($acf_map[$source_type])) {
                $skipped++;
                continue;
            }

            $ok = $this->map_acf_fields($post_id, $item, $source_type, $acf_map, !empty($settings['import_images']));
            if ($ok) {
                $updated++;
            } else {
                $errors[] = array(
                    'post_id' => $post_id,
                    'message' => 'Errore applicazione mapping.',
                );
            }
        }

        return array(
            'ok' => true,
            'mode' => 'apply_mapping',
            'processed' => $processed,
            'updated' => $updated,
            'skipped' => $skipped,
            'errors' => $errors,
        );
    }

    protected function fetch_endpoint_data($endpoint_url) {
        if (empty($endpoint_url)) {
            return array(
                'ok' => false,
                'message' => 'Endpoint URL mancante.',
            );
        }

        $settings = $this->get_settings();
        $headers = array(
            'Accept' => 'application/json',
        );

        if (!empty($settings['auth_bearer_token'])) {
            $headers['Authorization'] = 'Bearer ' . $settings['auth_bearer_token'];
        }

        $response = wp_remote_get($endpoint_url, array(
            'timeout' => 40,
            'headers' => $headers,
            'user-agent' => !empty($settings['request_user_agent']) ? $settings['request_user_agent'] : 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)',
        ));

        if (is_wp_error($response)) {
            return array(
                'ok' => false,
                'message' => $response->get_error_message(),
            );
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($status < 200 || $status >= 300) {
            return array(
                'ok' => false,
                'message' => 'HTTP status non valido: ' . $status,
            );
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded) || !isset($decoded['data']) || !is_array($decoded['data'])) {
            return array(
                'ok' => false,
                'message' => 'Formato JSON non valido: atteso oggetto con chiave data[].',
            );
        }

        return array(
            'ok' => true,
            'data' => $decoded['data'],
            'meta' => isset($decoded['meta']) && is_array($decoded['meta']) ? $decoded['meta'] : array(),
        );
    }

    protected function import_single_item($item, $settings, $type_map, $acf_map, $apply_mapping) {
        $source_type = isset($item['type']) ? sanitize_key($item['type']) : '';
        $post_type = $settings['default_post_type'];

        if ($source_type && isset($type_map[$source_type])) {
            $candidate = sanitize_key($type_map[$source_type]);
            if (post_type_exists($candidate)) {
                $post_type = $candidate;
            }
        }

        if (!post_type_exists($post_type)) {
            return array(
                'status' => 'error',
                'message' => 'Post type non esistente: ' . $post_type,
            );
        }

        $uuid = isset($item['uuid']) ? sanitize_text_field((string) $item['uuid']) : '';
        $nid = isset($item['nid']) ? absint($item['nid']) : 0;
        $langcode = isset($item['langcode']) ? sanitize_key($item['langcode']) : '';

        $existing_post_id = $this->find_existing_post($uuid, $nid, $post_type);

        $title = $this->extract_scalar_value(isset($item['title']) ? $item['title'] : '');
        if ($title === '') {
            $title = sprintf(__('Import item %d', 'site-json-acf-importer'), $nid ?: 0);
        }

        $content = '';
        if (isset($item['body'])) {
            $content = $this->extract_body_value($item['body']);
        }

        $excerpt = '';
        if (isset($item['summary'])) {
            $excerpt = $this->extract_scalar_value($item['summary']);
        }

        $postarr = array(
            'post_type' => $post_type,
            'post_status' => $settings['default_status'],
            'post_title' => wp_strip_all_tags($title),
            'post_content' => $content,
            'post_excerpt' => $excerpt,
        );

        if ($existing_post_id) {
            $postarr['ID'] = $existing_post_id;
            $post_id = wp_update_post($postarr, true);
            $action = 'updated';
        } else {
            $post_id = wp_insert_post($postarr, true);
            $action = 'created';
        }

        if (is_wp_error($post_id)) {
            return array(
                'status' => 'error',
                'message' => $post_id->get_error_message(),
            );
        }

        if ($uuid !== '') {
            update_post_meta($post_id, '_sjai_source_uuid', $uuid);
        }
        if ($nid > 0) {
            update_post_meta($post_id, '_sjai_source_nid', $nid);
        }
        if ($source_type !== '') {
            update_post_meta($post_id, '_sjai_source_type', $source_type);
        }
        if ($langcode !== '') {
            update_post_meta($post_id, '_sjai_source_langcode', $langcode);
        }

        $this->store_source_index_meta($post_id, $item);

        update_post_meta($post_id, '_sjai_raw_item', wp_json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($apply_mapping) {
            $this->map_acf_fields($post_id, $item, $source_type, $acf_map, !empty($settings['import_images']));
        }

        return array(
            'status' => $action,
            'post_id' => $post_id,
        );
    }

    protected function store_source_index_meta($post_id, $item) {
        if (!is_array($item)) {
            return;
        }

        foreach ($item as $field_name => $value) {
            $field_key = sanitize_key($field_name);
            if ($field_key === '') {
                continue;
            }

            if (is_string($value) || is_numeric($value)) {
                update_post_meta($post_id, '_sjai_src_' . $field_key, (string) $value);
                continue;
            }

            $scalar = $this->extract_scalar_value($value);
            if ($scalar !== '') {
                update_post_meta($post_id, '_sjai_src_' . $field_key, $scalar);
            }
        }
    }

    protected function find_existing_post($uuid, $nid, $post_type) {
        if ($uuid !== '') {
            $posts = get_posts(array(
                'post_type' => $post_type,
                'post_status' => 'any',
                'fields' => 'ids',
                'posts_per_page' => 1,
                'meta_key' => '_sjai_source_uuid',
                'meta_value' => $uuid,
            ));

            if (!empty($posts)) {
                return (int) $posts[0];
            }
        }

        if ($nid > 0) {
            $posts = get_posts(array(
                'post_type' => $post_type,
                'post_status' => 'any',
                'fields' => 'ids',
                'posts_per_page' => 1,
                'meta_key' => '_sjai_source_nid',
                'meta_value' => $nid,
            ));

            if (!empty($posts)) {
                return (int) $posts[0];
            }
        }

        return 0;
    }

    protected function map_acf_fields($post_id, $item, $source_type, $acf_map, $import_images) {
        if (empty($source_type) || empty($acf_map[$source_type]) || !is_array($acf_map[$source_type])) {
            return false;
        }

        $post_update = array('ID' => (int) $post_id);
        $has_post_update = false;

        foreach ($acf_map[$source_type] as $source_field => $acf_field_name) {
            if (!array_key_exists($source_field, $item)) {
                continue;
            }

            $value = $item[$source_field];
            $target = is_string($acf_field_name) ? trim($acf_field_name) : '';
            if ($target === '') {
                continue;
            }

            if (strpos($target, 'wp:') === 0) {
                $wp_target = substr($target, 3);
                if ($wp_target === 'post_title') {
                    $post_update['post_title'] = wp_strip_all_tags($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_target === 'post_content') {
                    $post_update['post_content'] = $this->extract_body_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'post_excerpt') {
                    $post_update['post_excerpt'] = $this->extract_scalar_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'post_name') {
                    $post_update['post_name'] = sanitize_title($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_target === 'menu_order') {
                    $post_update['menu_order'] = (int) $this->extract_scalar_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'featured_image') {
                    $featured_value = $this->normalize_for_acf($value, $import_images, $post_id);
                    if (is_numeric($featured_value) && (int) $featured_value > 0) {
                        set_post_thumbnail($post_id, (int) $featured_value);
                    }
                }
                continue;
            }

            if (strpos($target, 'yoast:') === 0) {
                $yoast_target = substr($target, 6);
                $yoast_key = $this->get_yoast_meta_key($yoast_target);
                if ($yoast_key !== '') {
                    update_post_meta($post_id, $yoast_key, $this->extract_scalar_value($value));
                }
                continue;
            }

            if (strpos($target, 'acf:') === 0) {
                $acf_field = substr($target, 4);
            } else {
                $acf_field = $target;
            }

            $normalized = $this->normalize_for_acf($value, $import_images, $post_id);
            if (function_exists('update_field')) {
                update_field($acf_field, $normalized, $post_id);
            } else {
                update_post_meta($post_id, $acf_field, $normalized);
            }
        }

        if ($has_post_update) {
            wp_update_post($post_update);
        }

        return true;
    }

    protected function get_yoast_meta_key($target) {
        $map = array(
            'seo_title' => '_yoast_wpseo_title',
            'meta_description' => '_yoast_wpseo_metadesc',
            'focus_keyword' => '_yoast_wpseo_focuskw',
            'canonical' => '_yoast_wpseo_canonical',
            'og_title' => '_yoast_wpseo_opengraph-title',
            'og_description' => '_yoast_wpseo_opengraph-description',
            'twitter_title' => '_yoast_wpseo_twitter-title',
            'twitter_description' => '_yoast_wpseo_twitter-description',
        );

        return isset($map[$target]) ? $map[$target] : '';
    }

    protected function normalize_for_acf($value, $import_images, $post_id = 0) {
        if (is_array($value) && isset($value['url']) && is_string($value['url'])) {
            if ($import_images) {
                $attachment_id = $this->sideload_image($value['url'], $value, $post_id);
                if ($attachment_id > 0) {
                    return $attachment_id;
                }
            }
            return esc_url_raw($value['url']);
        }

        if (is_array($value) && isset($value[0]) && is_array($value[0]) && isset($value[0]['url'])) {
            if ($import_images) {
                $ids = array();
                foreach ($value as $entry) {
                    if (!isset($entry['url']) || !is_string($entry['url'])) {
                        continue;
                    }
                    $attachment_id = $this->sideload_image($entry['url'], $entry, $post_id);
                    if ($attachment_id > 0) {
                        $ids[] = $attachment_id;
                    }
                }
                if (!empty($ids)) {
                    return $ids;
                }
            }

            $urls = array();
            foreach ($value as $entry) {
                if (isset($entry['url']) && is_string($entry['url'])) {
                    $urls[] = esc_url_raw($entry['url']);
                }
            }
            return $urls;
        }

        if (is_array($value)) {
            if (isset($value['value']) && count($value) === 1) {
                return $value['value'];
            }

            return $value;
        }

        return $value;
    }

    protected function sideload_image($url, $image_meta = array(), $post_id = 0) {
        if (!is_string($url) || $url === '') {
            return 0;
        }

        if (!function_exists('media_sideload_image')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $temp_file = download_url($url, 30);
        if (is_wp_error($temp_file)) {
            return 0;
        }

        $parsed_url = parse_url($url, PHP_URL_PATH);
        if (!is_string($parsed_url) || $parsed_url === '') {
            $parsed_url = 'imported-image.jpg';
        }

        $file_array = array(
            'name' => wp_basename($parsed_url),
            'tmp_name' => $temp_file,
        );

        $attachment_id = media_handle_sideload($file_array, (int) $post_id);

        if (is_wp_error($attachment_id)) {
            @unlink($temp_file);
            return 0;
        }

        if (is_array($image_meta)) {
            if (!empty($image_meta['alt']) && is_string($image_meta['alt'])) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($image_meta['alt']));
            }

            if (!empty($image_meta['title']) && is_string($image_meta['title'])) {
                wp_update_post(array(
                    'ID' => (int) $attachment_id,
                    'post_title' => sanitize_text_field($image_meta['title']),
                ));
            }
        }

        return (int) $attachment_id;
    }

    protected function get_target_field_options() {
        $options = array(
            'wp:post_title' => 'WordPress: Titolo post (post_title)',
            'wp:post_content' => 'WordPress: Contenuto post (post_content)',
            'wp:post_excerpt' => 'WordPress: Riassunto (post_excerpt)',
            'wp:post_name' => 'WordPress: Slug (post_name)',
            'wp:menu_order' => 'WordPress: Ordinamento menu (menu_order)',
            'wp:featured_image' => 'WordPress: Immagine in evidenza',
            'yoast:seo_title' => 'Yoast: SEO Title',
            'yoast:meta_description' => 'Yoast: Meta Description',
            'yoast:focus_keyword' => 'Yoast: Focus Keyword',
            'yoast:canonical' => 'Yoast: Canonical URL',
            'yoast:og_title' => 'Yoast: OpenGraph Title',
            'yoast:og_description' => 'Yoast: OpenGraph Description',
            'yoast:twitter_title' => 'Yoast: Twitter Title',
            'yoast:twitter_description' => 'Yoast: Twitter Description',
        );

        $acf_fields_found = false;

        if (function_exists('acf_get_field_groups') && function_exists('acf_get_fields')) {
            $groups = acf_get_field_groups();
            foreach ($groups as $group) {
                $fields = acf_get_fields($group);
                if (!is_array($fields)) {
                    continue;
                }

                foreach ($fields as $field) {
                    if (empty($field['name'])) {
                        continue;
                    }

                    $name = (string) $field['name'];
                    $label = !empty($field['label']) ? (string) $field['label'] : $name;
                    $type = !empty($field['type']) ? (string) $field['type'] : 'unknown';
                    $options['acf:' . $name] = 'ACF: ' . $label . ' (' . $name . ' - ' . $type . ')';
                    $acf_fields_found = true;
                }
            }
        }

        if (!$acf_fields_found) {
            $options['acf:manual_field_name'] = __('ACF: nessun campo rilevato (controlla ACF Pro attivo)', 'site-json-acf-importer');
        }

        asort($options);

        return $options;
    }

    protected function extract_body_value($body) {
        if (is_array($body)) {
            if (isset($body['value']) && is_string($body['value'])) {
                return $body['value'];
            }

            if (isset($body[0]) && is_array($body[0]) && isset($body[0]['value']) && is_string($body[0]['value'])) {
                return $body[0]['value'];
            }
        }

        if (is_string($body)) {
            return $body;
        }

        return '';
    }

    protected function extract_scalar_value($value) {
        if (is_string($value) || is_numeric($value)) {
            return (string) $value;
        }

        if (is_array($value)) {
            if (isset($value['value']) && (is_string($value['value']) || is_numeric($value['value']))) {
                return (string) $value['value'];
            }
            if (isset($value[0]['value']) && (is_string($value[0]['value']) || is_numeric($value[0]['value']))) {
                return (string) $value[0]['value'];
            }
        }

        return '';
    }
}
