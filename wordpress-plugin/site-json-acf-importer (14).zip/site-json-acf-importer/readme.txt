=== Site JSON ACF Importer ===
Contributors: custom
Tags: import, json, acf, drupal
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Importa contenuti JSON da endpoint esterno (es. Drupal) e li salva in WordPress, con mapping campi ACF Pro.

== Installazione ==
1. Copia la cartella site-json-acf-importer in wp-content/plugins/
2. Attiva il plugin da Plugin
3. Vai su Strumenti > Site JSON Importer
4. Configura URL endpoint e opzioni base
5. Esegui "Step 1: Import JSON grezzo"
6. Configura il mapping dalla UI (tipo sorgente -> post type e campi sorgente -> ACF)
7. Esegui "Step 2: Applica mapping ai contenuti importati"
8. Opzionale: attiva la modalita parent a 2 passaggi, indicando campo sorgente parent e campo di merge

== Note ==
- Se ACF Pro non e presente, i contenuti vengono comunque importati su titolo/contenuto/excerpt e metadati.
- Lo Step 1 salva anche il payload grezzo per ogni contenuto, utile per applicare/ripetere mapping senza dover reimportare dal JSON.
- Il plugin usa uuid/nid per aggiornare contenuti gia importati.
- In caso di errore HTTP 403, verifica i permessi dell'endpoint Drupal e usa, se necessario, Bearer token/User-Agent configurabili nel plugin.
- Nel mapping UI puoi scegliere destinazioni WordPress core, campi Yoast SEO e campi ACF.
- Per campi sorgente complessi (array/oggetti), puoi scegliere anche quale elemento interno usare (es: value, [0].url, [*].target_id).
- Nello Step 2 puoi aprire un'anteprima dei dati reali del JSON di test e scorrere i record con i pulsanti Precedente/Successivo.
- Se abiliti il parent linking, lo Step 1 importa prima tutti i contenuti e poi esegue un secondo giro per valorizzare post_parent.

== Changelog ==

= 1.5.4 =
* FIX CRITICO: Aggiunto header JSON content-type prima di OGNI output per force browser parsing como JSON
* FIX CRITICO: Implementato while(@ob_end_clean()) per clearare TUTTI i buffer precedenti non catturati
* FIX: Aggiunto error suppression operator (@) su funzioni che potrebbero generare warnings (check_ajax_referer, fetch_endpoint_data)
* FIX: Aggiunto transient validation con check is_array prima di usare state
* IMPROVEMENT: Entrambi gli endpoint AJAX (start e process) ora hanno protezione output buffer identica
* IMPROVEMENT: Cambiato Exception a \Throwable nei catch per catturare anche ParseError e TypeError

= 1.5.3 =
* FIX: Aggiunto ob_start/ob_end_clean in ajax_process_batch per evitare output HTML prima del JSON
* FIX: Wrap try-catch attorno al loop di import batch per catturare errori PHP
* FIX: Validazione robusta di payload prima di elaborare dati
* IMPROVEMENT: Errori PHP ora catturati e loggati invece di breakare il JSON

= 1.5.2 =
* FIX CRITICO: Rimosso dataset intero dal transient state - causava JSON parsing error su batch successivi
* REFACTOR: Async ora refetch dati da endpoint ad ogni batch invece di mantenerli in memoria
* FIX: Evitato problema di serializzazione transient con array enormi
* IMPROVEMENT: Ridotto consumo memoria e transient storage per import grandi

= 1.5.1 =
* FIX: Corretto avanzamento batch async con cursore persistente nel transient
* FIX: Evitato reprocessing degli stessi record ai batch successivi
* FIX: Corretto criterio di completamento import async su fine dataset/range

= 1.5.0 =
* FIX: Corretto bug critico: il source_type '0' (valore PHP falsy) non veniva riconosciuto nel type_map, causando import sempre nel post type di default
* FIX: find_existing_post ora cerca anche tra tutti i post_type ('any') come fallback, così il re-import aggiorna correttamente i post già importati con tipo diverso
* FEATURE: Re-import converte automaticamente i post esistenti nel post_type corretto senza creare duplicati

= 1.4.2 =
* FIX: Corretto parse error in class-sjai-importer.php (apice in eccesso nella renderizzazione JS)
* FIX: Ripristinato caricamento pannello plugin senza errore critico

= 1.4.1 =
* FIX: Corretto errore critico nella renderizzazione JavaScript dell'async import
* FIX: Rimosso carattere di escape errato nei dati JavaScript renderizzati

= 1.4.0 =
* Feature: Sistema di import asincrono con progress bar
* Feature: Auto-retry su errori di rete (max 3 tentativi)
* Feature: Persistenza sessione in localStorage (ripresa da interruzione)
* Feature: Metriche real-time (velocità, tempo trascorso, stima tempo rimanente)
* Improvement: UI progress bar con gradient e animazione
