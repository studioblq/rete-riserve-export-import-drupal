<?php

if (!defined('ABSPATH')) {
    exit;
}

class SJAI_Importer {
    const OPTION_KEY = 'sjai_settings';
    const OPTION_SCHEMA_KEY = 'sjai_discovered_schema';
    const OPTION_PREVIEW_KEY = 'sjai_preview_samples';

    const NONCE_ACTION_SAVE = 'sjai_save_settings';
    const NONCE_ACTION_IMPORT_RAW = 'sjai_import_raw';
    const NONCE_ACTION_SAVE_MAPPING = 'sjai_save_mapping';
    const NONCE_ACTION_APPLY_MAPPING = 'sjai_apply_mapping';

    public function init() {
        add_action('admin_menu', array($this, 'register_admin_page'));
        add_action('admin_init', array($this, 'maybe_save_settings'));
        add_action('admin_post_sjai_import_raw', array($this, 'handle_raw_import'));
        add_action('admin_post_sjai_save_mapping', array($this, 'handle_save_mapping'));
        add_action('admin_post_sjai_apply_mapping', array($this, 'handle_apply_mapping'));
    }

    public function register_admin_page() {
        add_management_page(
            __('Site JSON Importer', 'site-json-acf-importer'),
            __('Site JSON Importer', 'site-json-acf-importer'),
            'manage_options',
            'site-json-acf-importer',
            array($this, 'render_admin_page')
        );
    }

    public function maybe_save_settings() {
        if (!is_admin()) {
            return;
        }

        if (!isset($_POST['sjai_action']) || $_POST['sjai_action'] !== 'save_settings') {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_SAVE);

        $settings = $this->get_settings();
        $settings['endpoint_url'] = isset($_POST['endpoint_url']) ? esc_url_raw(trim(wp_unslash($_POST['endpoint_url']))) : '';
        $settings['default_post_type'] = isset($_POST['default_post_type']) ? sanitize_key(wp_unslash($_POST['default_post_type'])) : 'post';
        $settings['default_status'] = isset($_POST['default_status']) ? sanitize_key(wp_unslash($_POST['default_status'])) : 'draft';
        $settings['import_images'] = !empty($_POST['import_images']) ? 1 : 0;
        $settings['auth_bearer_token'] = isset($_POST['auth_bearer_token']) ? sanitize_text_field(trim(wp_unslash($_POST['auth_bearer_token']))) : '';
        $settings['request_user_agent'] = isset($_POST['request_user_agent']) ? sanitize_text_field(trim(wp_unslash($_POST['request_user_agent']))) : 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)';
        $settings['enable_parent_linking'] = !empty($_POST['enable_parent_linking']) ? 1 : 0;
        $settings['parent_source_field'] = isset($_POST['parent_source_field']) ? sanitize_key(trim(wp_unslash($_POST['parent_source_field']))) : '';
        $settings['parent_match_field'] = isset($_POST['parent_match_field']) ? sanitize_key(trim(wp_unslash($_POST['parent_match_field']))) : 'nid';
        $settings['merge_reference_field'] = isset($_POST['merge_reference_field']) ? sanitize_key(trim(wp_unslash($_POST['merge_reference_field']))) : 'uuid';

        if (!post_type_exists($settings['default_post_type'])) {
            $settings['default_post_type'] = 'post';
        }

        update_option(self::OPTION_KEY, $settings);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'settings_saved',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_raw_import() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_IMPORT_RAW);

        $result = $this->run_raw_import();
        set_transient('sjai_last_import_result_' . get_current_user_id(), $result, MINUTE_IN_SECONDS * 10);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'raw_import_done',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_save_mapping() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_SAVE_MAPPING);

        $settings = $this->get_settings();
        $post_types = get_post_types(array(), 'names');

        $raw_type_map = isset($_POST['type_map_ui']) && is_array($_POST['type_map_ui']) ? wp_unslash($_POST['type_map_ui']) : array();
        $type_map_ui = array();
        foreach ($raw_type_map as $source_type => $wp_post_type) {
            $source_key = sanitize_key($source_type);
            $target_key = sanitize_key($wp_post_type);
            if ($source_key === '') {
                continue;
            }
            if (!in_array($target_key, $post_types, true)) {
                $target_key = $settings['default_post_type'];
            }
            $type_map_ui[$source_key] = $target_key;
        }

        $raw_acf_map = isset($_POST['acf_map_ui']) && is_array($_POST['acf_map_ui']) ? wp_unslash($_POST['acf_map_ui']) : array();
        $acf_map_ui = array();
        foreach ($raw_acf_map as $source_type => $map) {
            $source_key = sanitize_key($source_type);
            if ($source_key === '' || !is_array($map)) {
                continue;
            }

            foreach ($map as $source_field => $acf_field_name) {
                $field_key = sanitize_key($source_field);
                $acf_name = sanitize_text_field($acf_field_name);
                if ($field_key === '' || $acf_name === '') {
                    continue;
                }
                if (!isset($acf_map_ui[$source_key])) {
                    $acf_map_ui[$source_key] = array();
                }
                $acf_map_ui[$source_key][$field_key] = $acf_name;
            }
        }

        $raw_acf_path_map = isset($_POST['acf_map_path_ui']) && is_array($_POST['acf_map_path_ui']) ? wp_unslash($_POST['acf_map_path_ui']) : array();
        $acf_map_path_ui = array();
        foreach ($raw_acf_path_map as $source_type => $map) {
            $source_key = sanitize_key($source_type);
            if ($source_key === '' || !is_array($map)) {
                continue;
            }

            foreach ($map as $source_field => $path) {
                $field_key = sanitize_key($source_field);
                if ($field_key === '') {
                    continue;
                }

                $path_value = is_string($path) ? trim(sanitize_text_field($path)) : '';
                if ($path_value !== '' && !preg_match('/^[A-Za-z0-9_\.\[\]\*]+$/', $path_value)) {
                    continue;
                }

                if (!isset($acf_map_path_ui[$source_key])) {
                    $acf_map_path_ui[$source_key] = array();
                }
                $acf_map_path_ui[$source_key][$field_key] = $path_value;
            }
        }

        $raw_field_map = isset($_POST['field_map_v2']) && is_array($_POST['field_map_v2']) ? wp_unslash($_POST['field_map_v2']) : array();
        $field_map_v2 = array();
        foreach ($raw_field_map as $source_type => $rows) {
            $source_key = sanitize_key($source_type);
            if ($source_key === '' || !is_array($rows)) {
                continue;
            }
            $clean_rows = array();
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $wp_target = isset($row['wp']) ? sanitize_text_field(trim($row['wp'])) : '';
                if ($wp_target === '' || !preg_match('/^(wp:|yoast:|acf:)/', $wp_target)) {
                    continue;
                }
                $entry = array(
                    'wp'            => $wp_target,
                    'src'           => isset($row['src']) ? sanitize_key($row['src']) : '',
                    'path'          => '',
                    'img_alt_src'   => isset($row['img_alt_src']) ? sanitize_key($row['img_alt_src']) : '',
                    'img_alt_path'  => '',
                    'img_title_src' => isset($row['img_title_src']) ? sanitize_key($row['img_title_src']) : '',
                    'img_title_path'=> '',
                );
                foreach (array('path', 'img_alt_path', 'img_title_path') as $path_key) {
                    $p = isset($row[$path_key]) ? trim(sanitize_text_field($row[$path_key])) : '';
                    if ($p !== '' && preg_match('/^[A-Za-z0-9_\.\[\]\*]+$/', $p)) {
                        $entry[$path_key] = $p;
                    }
                }
                $clean_rows[] = $entry;
            }
            if (!empty($clean_rows)) {
                $field_map_v2[$source_key] = array_values($clean_rows);
            }
        }

        $settings['type_map_ui']    = $type_map_ui;
        $settings['acf_map_ui']     = $acf_map_ui;
        $settings['acf_map_path_ui']= $acf_map_path_ui;
        $settings['field_map_v2']   = $field_map_v2;
        update_option(self::OPTION_KEY, $settings);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'mapping_saved',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_apply_mapping() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato.', 'site-json-acf-importer'));
        }

        check_admin_referer(self::NONCE_ACTION_APPLY_MAPPING);

        $result = $this->run_apply_mapping();
        set_transient('sjai_last_mapping_result_' . get_current_user_id(), $result, MINUTE_IN_SECONDS * 10);

        $redirect = add_query_arg(
            array(
                'page' => 'site-json-acf-importer',
                'sjai_notice' => 'mapping_applied',
            ),
            admin_url('tools.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();
        $post_type_objects = get_post_types(array('public' => true), 'objects');
        $statuses = array(
            'draft' => __('Bozza', 'site-json-acf-importer'),
            'publish' => __('Pubblicato', 'site-json-acf-importer'),
            'pending' => __('In attesa', 'site-json-acf-importer'),
            'private' => __('Privato', 'site-json-acf-importer'),
        );
        $schema = $this->get_discovered_schema();
        $preview_samples = $this->get_preview_samples();
        $target_options = $this->get_target_field_options();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Site JSON Importer', 'site-json-acf-importer') . '</h1>';

        $this->render_notice();

        echo '<h2>' . esc_html__('Configurazione base', 'site-json-acf-importer') . '</h2>';
        echo '<form method="post" action="">';
        wp_nonce_field(self::NONCE_ACTION_SAVE);
        echo '<input type="hidden" name="sjai_action" value="save_settings" />';

        echo '<table class="form-table" role="presentation">';

        echo '<tr>';
        echo '<th scope="row"><label for="endpoint_url">' . esc_html__('URL endpoint JSON', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="endpoint_url" id="endpoint_url" type="url" class="regular-text" value="' . esc_attr($settings['endpoint_url']) . '" placeholder="https://example.com/it/site-json-export" required />';
        echo '<p class="description">' . esc_html__('Endpoint con struttura { meta, data[] }.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="auth_bearer_token">' . esc_html__('Bearer token (opzionale)', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="auth_bearer_token" id="auth_bearer_token" type="text" class="regular-text" value="' . esc_attr($settings['auth_bearer_token']) . '" />';
        echo '<p class="description">' . esc_html__('Se valorizzato, il plugin invia header Authorization: Bearer <token>.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="request_user_agent">' . esc_html__('User-Agent richiesta', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="request_user_agent" id="request_user_agent" type="text" class="regular-text" value="' . esc_attr($settings['request_user_agent']) . '" />';
        echo '<p class="description">' . esc_html__('Utile se firewall o CDN bloccano lo user-agent di default.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="default_post_type">' . esc_html__('Post type di default', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<select name="default_post_type" id="default_post_type">';
        foreach ($post_type_objects as $post_type => $obj) {
            echo '<option value="' . esc_attr($post_type) . '" ' . selected($settings['default_post_type'], $post_type, false) . '>' . esc_html($obj->labels->singular_name) . ' (' . esc_html($post_type) . ')</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="default_status">' . esc_html__('Stato post', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<select name="default_status" id="default_status">';
        foreach ($statuses as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($settings['default_status'], $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Importa immagini', 'site-json-acf-importer') . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="import_images" value="1" ' . checked(1, $settings['import_images'], false) . ' /> ' . esc_html__('Scarica immagini remote e salva anche ALT e TITLE negli attachment.', 'site-json-acf-importer') . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Assegna parent in secondo giro', 'site-json-acf-importer') . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="enable_parent_linking" value="1" ' . checked(1, $settings['enable_parent_linking'], false) . ' /> ' . esc_html__('Se attivo, dopo l\'import il plugin esegue un secondo passaggio e valorizza post_parent.', 'site-json-acf-importer') . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="parent_source_field">' . esc_html__('Campo sorgente che contiene il parent', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="parent_source_field" id="parent_source_field" type="text" class="regular-text" value="' . esc_attr($settings['parent_source_field']) . '" placeholder="field_contenuto_padre" />';
        echo '<p class="description">' . esc_html__('Nome del campo JSON sul contenuto figlio che contiene il valore identificativo del parent.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="parent_match_field">' . esc_html__('Campo di merge per trovare il parent', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="parent_match_field" id="parent_match_field" type="text" class="regular-text" value="' . esc_attr($settings['parent_match_field']) . '" placeholder="nid / uuid / field_custom_id" />';
        echo '<p class="description">' . esc_html__('Il valore del campo parent del figlio viene confrontato con questo campo sui contenuti importati (es: nid, uuid, o un campo custom).', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="merge_reference_field">' . esc_html__('Campo riferimento per update reimport', 'site-json-acf-importer') . '</label></th>';
        echo '<td>';
        echo '<input name="merge_reference_field" id="merge_reference_field" type="text" class="regular-text" value="' . esc_attr($settings['merge_reference_field']) . '" placeholder="uuid / nid / field_custom_id" />';
        echo '<p class="description">' . esc_html__('Nel reimport il contenuto viene aggiornato (non aggiunto) se trova un match su questo campo.', 'site-json-acf-importer') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';
        submit_button(__('Salva impostazioni', 'site-json-acf-importer'));
        echo '</form>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Step 1: Analisi struttura JSON', 'site-json-acf-importer') . '</h2>';
        echo '<p>' . esc_html__('Legge solo il JSON e rileva tipi/campi disponibili per il mapping UI. Non crea o aggiorna contenuti WordPress.', 'site-json-acf-importer') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(self::NONCE_ACTION_IMPORT_RAW);
        echo '<input type="hidden" name="action" value="sjai_import_raw" />';
        submit_button(__('Analizza JSON', 'site-json-acf-importer'), 'primary', 'submit', false);
        echo '</form>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Step 2: Mapping UI e import reale', 'site-json-acf-importer') . '</h2>';

        if (empty($schema['types'])) {
            echo '<p><em>' . esc_html__('Nessuno schema rilevato. Esegui prima lo Step 1.', 'site-json-acf-importer') . '</em></p>';
        } else {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field(self::NONCE_ACTION_SAVE_MAPPING);
            echo '<input type="hidden" name="action" value="sjai_save_mapping" />';

            echo '<h3>' . esc_html__('Mapping tipi sorgente -> post type WordPress', 'site-json-acf-importer') . '</h3>';
            echo '<table class="widefat striped" style="max-width:1000px">';
            echo '<thead><tr><th>' . esc_html__('Tipo sorgente', 'site-json-acf-importer') . '</th><th>' . esc_html__('Post type WordPress', 'site-json-acf-importer') . '</th></tr></thead><tbody>';

            foreach ($schema['types'] as $source_type => $fields) {
                $selected_post_type = isset($settings['type_map_ui'][$source_type]) ? $settings['type_map_ui'][$source_type] : $settings['default_post_type'];
                echo '<tr>';
                echo '<td><strong>' . esc_html($source_type) . '</strong></td>';
                echo '<td><select name="type_map_ui[' . esc_attr($source_type) . ']">';
                foreach ($post_type_objects as $post_type => $obj) {
                    echo '<option value="' . esc_attr($post_type) . '" ' . selected($selected_post_type, $post_type, false) . '>' . esc_html($obj->labels->singular_name) . ' (' . esc_html($post_type) . ')</option>';
                }
                echo '</select></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            $this->render_field_map_section($schema, $settings, $target_options);

            submit_button(__('Salva mapping UI', 'site-json-acf-importer'));
            echo '</form>';

            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:10px">';
            wp_nonce_field(self::NONCE_ACTION_APPLY_MAPPING);
            echo '<input type="hidden" name="action" value="sjai_apply_mapping" />';
            submit_button(__('Importa dati', 'site-json-acf-importer'), 'secondary', 'submit', false);
            echo '</form>';

            if (!empty($preview_samples['by_type'])) {
                echo '<div id="sjai-preview-panel" style="margin-top:15px;border:1px solid #ccd0d4;background:#fff;padding:12px;max-width:1100px;display:none;">';
                echo '<h3 style="margin-top:0;">' . esc_html__('Anteprima valori da JSON di test', 'site-json-acf-importer') . '</h3>';
                echo '<p id="sjai-preview-meta" class="description" style="margin-top:0;"></p>';
                echo '<p>';
                echo '<button type="button" class="button" id="sjai-preview-prev">' . esc_html__('Precedente', 'site-json-acf-importer') . '</button> ';
                echo '<button type="button" class="button" id="sjai-preview-next">' . esc_html__('Successivo', 'site-json-acf-importer') . '</button> ';
                echo '<button type="button" class="button" id="sjai-preview-close">' . esc_html__('Chiudi', 'site-json-acf-importer') . '</button>';
                echo '</p>';
                echo '<pre id="sjai-preview-value" style="background:#f8f9fa;border:1px solid #e0e0e0;padding:12px;overflow:auto;max-height:360px;"></pre>';
                echo '</div>';

                echo '<script>';
                echo 'window.sjaiPreviewSamples = ' . wp_json_encode($preview_samples['by_type'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';';
                echo '(function(){';
                echo 'var panel=document.getElementById("sjai-preview-panel");';
                echo 'var meta=document.getElementById("sjai-preview-meta");';
                echo 'var valueBox=document.getElementById("sjai-preview-value");';
                echo 'var prevBtn=document.getElementById("sjai-preview-prev");';
                echo 'var nextBtn=document.getElementById("sjai-preview-next");';
                echo 'var closeBtn=document.getElementById("sjai-preview-close");';
                echo 'var state={type:"",field:"",pathSelectId:"",index:0};';
                echo 'function tokens(path){var m=path.match(/(\\[\\*\\]|\\[\\d+\\]|[^\\.\\[\\]]+)/g);return m||[];}';
                echo 'function extractBySegments(value,segments,idx){if(idx>=segments.length){return value;}var seg=segments[idx];if(seg==="[*]"){if(!Array.isArray(value)){return null;}var out=[];for(var i=0;i<value.length;i++){var ex=extractBySegments(value[i],segments,idx+1);if(ex===null||ex===""||(Array.isArray(ex)&&ex.length===0)){continue;}out.push(ex);}return out;}var m=seg.match(/^\\[(\\d+)\\]$/);if(m){var pos=parseInt(m[1],10);if(!Array.isArray(value)||!(pos in value)){return null;}return extractBySegments(value[pos],segments,idx+1);}if(!value||typeof value!=="object"||!(seg in value)){return null;}return extractBySegments(value[seg],segments,idx+1);}';
                echo 'function extractByPath(value,path){if(!path){return value;}var segs=tokens(path);if(!segs.length){return value;}return extractBySegments(value,segs,0);}';
                echo 'function currentPath(){var el=document.getElementById(state.pathSelectId);return el?el.value:"";}';
                echo 'function render(){var all=(window.sjaiPreviewSamples&&window.sjaiPreviewSamples[state.type])?window.sjaiPreviewSamples[state.type]:[];if(!all.length){meta.textContent="Nessun record di test disponibile per questo tipo.";valueBox.textContent="";prevBtn.disabled=true;nextBtn.disabled=true;return;}if(state.index<0){state.index=0;}if(state.index>=all.length){state.index=all.length-1;}var item=all[state.index]||{};var raw=(item&&Object.prototype.hasOwnProperty.call(item,state.field))?item[state.field]:null;var val=extractByPath(raw,currentPath());var shown=(val===null)?"(nessun valore)":JSON.stringify(val,null,2);meta.textContent="Tipo: "+state.type+" | Campo: "+state.field+" | Record "+(state.index+1)+" di "+all.length;valueBox.textContent=shown;prevBtn.disabled=(state.index<=0);nextBtn.disabled=(state.index>=all.length-1);}';
                echo 'function openPreview(type,field,pathSelectId){state.type=type;state.field=field;state.pathSelectId=pathSelectId;state.index=0;panel.style.display="block";render();}';
                echo 'window.sjaiOpenPreview=openPreview;';
                echo 'document.querySelectorAll(".sjai-preview-open").forEach(function(btn){btn.addEventListener("click",function(){openPreview(btn.getAttribute("data-sjai-type")||"",btn.getAttribute("data-sjai-field")||"",btn.getAttribute("data-sjai-path-select-id")||"");});});';
                echo 'document.querySelectorAll("select[name^=\"acf_map_path_ui[\"]").forEach(function(sel){sel.addEventListener("change",function(){if(panel.style.display!=="none"){render();}});});';
                echo 'prevBtn.addEventListener("click",function(){state.index--;render();});';
                echo 'nextBtn.addEventListener("click",function(){state.index++;render();});';
                echo 'closeBtn.addEventListener("click",function(){panel.style.display="none";});';
                echo '})();';
                echo '</script>';
            }

            $this->render_field_map_js();
        }

        $last_result = get_transient('sjai_last_import_result_' . get_current_user_id());
        if (is_array($last_result)) {
            echo '<h3>' . esc_html__('Ultimo risultato analisi JSON', 'site-json-acf-importer') . '</h3>';
            echo '<pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:1100px;overflow:auto;">' . esc_html(wp_json_encode($last_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '</pre>';
        }

        $last_mapping_result = get_transient('sjai_last_mapping_result_' . get_current_user_id());
        if (is_array($last_mapping_result)) {
            echo '<h3>' . esc_html__('Ultimo risultato import reale', 'site-json-acf-importer') . '</h3>';
            echo '<pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:1100px;overflow:auto;">' . esc_html(wp_json_encode($last_mapping_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '</pre>';
        }

        echo '</div>';
    }

    protected function render_notice() {
        if (empty($_GET['sjai_notice'])) {
            return;
        }

        $notice = sanitize_key(wp_unslash($_GET['sjai_notice']));
        if ($notice === 'settings_saved') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Impostazioni salvate.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'raw_import_done') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Step 1 completato: analisi struttura JSON eseguita.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'mapping_saved') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Mapping UI salvato.', 'site-json-acf-importer') . '</p></div>';
        }

        if ($notice === 'mapping_applied') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Step 2 completato: import reale con mapping eseguito.', 'site-json-acf-importer') . '</p></div>';
        }
    }

    protected function get_settings() {
        $defaults = array(
            'endpoint_url' => '',
            'default_post_type' => 'post',
            'default_status' => 'draft',
            'import_images' => 0,
            'auth_bearer_token' => '',
            'request_user_agent' => 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)',
            'enable_parent_linking' => 0,
            'parent_source_field' => '',
            'parent_match_field' => 'nid',
            'merge_reference_field' => 'uuid',
            'type_map_ui' => array(),
            'acf_map_ui' => array(),
            'acf_map_path_ui' => array(),
            'field_map_v2' => array(),
        );

        $saved = get_option(self::OPTION_KEY, array());
        $settings = wp_parse_args($saved, $defaults);

        if (!is_array($settings['type_map_ui'])) {
            $settings['type_map_ui'] = array();
        }

        if (!is_array($settings['acf_map_ui'])) {
            $settings['acf_map_ui'] = array();
        }

        if (!is_array($settings['acf_map_path_ui'])) {
            $settings['acf_map_path_ui'] = array();
        }

        if (!is_array($settings['field_map_v2'])) {
            $settings['field_map_v2'] = array();
        }

        return $settings;
    }

    protected function get_discovered_schema() {
        $schema = get_option(self::OPTION_SCHEMA_KEY, array());
        if (!is_array($schema) || !isset($schema['types']) || !is_array($schema['types'])) {
            return array('types' => array(), 'field_paths' => array());
        }

        foreach ($schema['types'] as $type => $fields) {
            if (!is_array($fields)) {
                unset($schema['types'][$type]);
                continue;
            }
            $fields = array_values(array_unique(array_map('sanitize_key', $fields)));
            $fields = array_values(array_filter($fields));
            sort($fields);
            $schema['types'][$type] = $fields;
        }

        $field_paths = array();
        if (isset($schema['field_paths']) && is_array($schema['field_paths'])) {
            foreach ($schema['field_paths'] as $type => $fields_map) {
                $type_key = sanitize_key($type);
                if ($type_key === '' || !is_array($fields_map)) {
                    continue;
                }

                foreach ($fields_map as $field => $paths) {
                    $field_key = sanitize_key($field);
                    if ($field_key === '' || !is_array($paths)) {
                        continue;
                    }

                    $valid_paths = array();
                    foreach ($paths as $path) {
                        $path_value = is_string($path) ? trim($path) : '';
                        if ($path_value === '' || !preg_match('/^[A-Za-z0-9_\.\[\]\*]+$/', $path_value)) {
                            continue;
                        }
                        $valid_paths[] = $path_value;
                    }

                    $valid_paths = array_values(array_unique($valid_paths));
                    sort($valid_paths);

                    if (!isset($field_paths[$type_key])) {
                        $field_paths[$type_key] = array();
                    }
                    $field_paths[$type_key][$field_key] = $valid_paths;
                }
            }
        }

        $schema['field_paths'] = $field_paths;

        return $schema;
    }

    protected function get_preview_samples() {
        $preview = get_option(self::OPTION_PREVIEW_KEY, array());
        if (!is_array($preview)) {
            return array('by_type' => array(), 'updated_at' => 0);
        }

        $by_type = array();
        if (isset($preview['by_type']) && is_array($preview['by_type'])) {
            foreach ($preview['by_type'] as $type => $items) {
                $type_key = sanitize_key($type);
                if ($type_key === '' || !is_array($items)) {
                    continue;
                }

                $clean_items = array();
                foreach ($items as $item) {
                    if (is_array($item)) {
                        $clean_items[] = $item;
                    }
                }
                $by_type[$type_key] = $clean_items;
            }
        }

        return array(
            'by_type' => $by_type,
            'updated_at' => isset($preview['updated_at']) ? (int) $preview['updated_at'] : 0,
        );
    }

    protected function run_raw_import() {
        $settings = $this->get_settings();
        $payload = $this->fetch_endpoint_data($settings['endpoint_url']);

        if (!$payload['ok']) {
            return $payload;
        }

        $data = $payload['data'];
        $skipped = 0;
        $schema_types = array();
        $schema_field_paths = array();
        $preview_by_type = array();
        $preview_limit_per_type = 25;
        $analyzed = 0;

        foreach ($data as $index => $item) {
            if (!is_array($item)) {
                $skipped++;
                continue;
            }

            $analyzed++;
            $source_type = isset($item['type']) ? sanitize_key($item['type']) : 'unknown';
            if ($source_type === '') {
                $source_type = 'unknown';
            }

            if (!isset($schema_types[$source_type])) {
                $schema_types[$source_type] = array();
            }

            if (!isset($preview_by_type[$source_type])) {
                $preview_by_type[$source_type] = array();
            }
            if (count($preview_by_type[$source_type]) < $preview_limit_per_type) {
                $preview_by_type[$source_type][] = $item;
            }

            foreach ($item as $key => $value) {
                $field_key = sanitize_key($key);
                if ($field_key === '') {
                    continue;
                }
                if (!in_array($field_key, $schema_types[$source_type], true)) {
                    $schema_types[$source_type][] = $field_key;
                }

                $paths = $this->discover_value_paths($value);
                if (!isset($schema_field_paths[$source_type])) {
                    $schema_field_paths[$source_type] = array();
                }
                if (!isset($schema_field_paths[$source_type][$field_key])) {
                    $schema_field_paths[$source_type][$field_key] = array();
                }
                foreach ($paths as $path) {
                    if (!in_array($path, $schema_field_paths[$source_type][$field_key], true)) {
                        $schema_field_paths[$source_type][$field_key][] = $path;
                    }
                }
            }

        }


        foreach ($schema_field_paths as $type => $fields_map) {
            foreach ($fields_map as $field => $paths) {
                $paths = array_values(array_unique($paths));
                sort($paths);
                $schema_field_paths[$type][$field] = $paths;
            }
        }
        update_option(self::OPTION_SCHEMA_KEY, array(
            'types' => $schema_types,
            'field_paths' => $schema_field_paths,
        ));
        update_option(self::OPTION_PREVIEW_KEY, array(
            'by_type' => $preview_by_type,
            'updated_at' => time(),
        ));
        return array(
            'ok' => true,
            'mode' => 'schema_discovery',
            'analyzed' => $analyzed,
            'skipped' => $skipped,
            'types_detected' => array_keys($schema_types),
        );
    }

    protected function assign_parents_second_pass($post_ids, $settings) {
        $result = array(
            'enabled' => true,
            'linked' => 0,
            'skipped' => 0,
            'errors' => array(),
            'multi_parent' => array(),
        );

        $source_field = isset($settings['parent_source_field']) ? sanitize_key($settings['parent_source_field']) : '';
        $match_field = isset($settings['parent_match_field']) ? sanitize_key($settings['parent_match_field']) : 'nid';

        if ($source_field === '') {
            $result['errors'][] = 'Campo sorgente parent non configurato.';
            return $result;
        }

        foreach ((array) $post_ids as $post_id) {
            $post_id = (int) $post_id;
            if ($post_id <= 0) {
                $result['skipped']++;
                continue;
            }

            $raw = get_post_meta($post_id, '_sjai_raw_item', true);
            if (!is_string($raw) || $raw === '') {
                $result['skipped']++;
                continue;
            }

            $item = json_decode($raw, true);
            if (!is_array($item) || !array_key_exists($source_field, $item)) {
                $result['skipped']++;
                continue;
            }

            $parent_references = $this->extract_all_parent_references($item[$source_field]);
            if (empty($parent_references)) {
                $result['skipped']++;
                continue;
            }

            $first_parent_post_id = 0;
            $all_parent_post_ids = array();

            foreach ($parent_references as $ref) {
                $found = $this->find_parent_post_id_by_merge_field($match_field, $ref);
                if ($found > 0 && $found !== $post_id) {
                    $all_parent_post_ids[] = $found;
                    if ($first_parent_post_id === 0) {
                        $first_parent_post_id = $found;
                    }
                }
            }

            if ($first_parent_post_id <= 0) {
                $result['skipped']++;
                continue;
            }

            $update = wp_update_post(array(
                'ID' => $post_id,
                'post_parent' => $first_parent_post_id,
            ), true);

            if (is_wp_error($update)) {
                $result['errors'][] = sprintf('Post %d: %s', $post_id, $update->get_error_message());
                continue;
            }

            update_post_meta($post_id, '_sjai_parent_ids', $all_parent_post_ids);

            if (count($all_parent_post_ids) > 1) {
                $result['multi_parent'][] = array(
                    'post_id' => $post_id,
                    'parents' => $all_parent_post_ids,
                );
            }

            $result['linked']++;
        }

        return $result;
    }

    protected function find_parent_post_id_by_merge_field($merge_field, $merge_value) {
        $meta_key = '';
        $meta_value = $merge_value;

        if ($merge_field === 'uuid') {
            $meta_key = '_sjai_source_uuid';
        } elseif ($merge_field === 'nid') {
            $meta_key = '_sjai_source_nid';
            $meta_value = (string) absint($merge_value);
        } else {
            $meta_key = '_sjai_src_' . sanitize_key($merge_field);
        }

        if ($meta_key === '') {
            return 0;
        }

        $posts = get_posts(array(
            'post_type' => 'any',
            'post_status' => 'any',
            'fields' => 'ids',
            'posts_per_page' => 1,
            'meta_key' => $meta_key,
            'meta_value' => $meta_value,
        ));

        if (empty($posts)) {
            return 0;
        }

        return (int) $posts[0];
    }

    protected function run_apply_mapping() {
        $settings = $this->get_settings();
        $acf_map      = is_array($settings['acf_map_ui'])      ? $settings['acf_map_ui']      : array();
        $acf_path_map = is_array($settings['acf_map_path_ui']) ? $settings['acf_map_path_ui'] : array();
        $field_map_v2 = is_array($settings['field_map_v2'])    ? $settings['field_map_v2']    : array();
        $type_map     = is_array($settings['type_map_ui'])     ? $settings['type_map_ui']     : array();

        $payload = $this->fetch_endpoint_data($settings['endpoint_url']);
        if (!$payload['ok']) {
            return $payload;
        }

        $data = $payload['data'];

        $processed = 0;
        $created = 0;
        $updated = 0;
        $skipped = 0;
        $errors = array();
        $imported_post_ids = array();

        foreach ($data as $index => $item) {
            if (!is_array($item)) {
                $skipped++;
                continue;
            }

            $processed++;

            $result = $this->import_single_item($item, $settings, $type_map, $acf_map, $acf_path_map, $field_map_v2, true);
            if ($result['status'] === 'created') {
                $created++;
                if (!empty($result['post_id'])) {
                    $imported_post_ids[] = (int) $result['post_id'];
                }
            } elseif ($result['status'] === 'updated') {
                $updated++;
                if (!empty($result['post_id'])) {
                    $imported_post_ids[] = (int) $result['post_id'];
                }
            } elseif ($result['status'] === 'skipped') {
                $skipped++;
            } else {
                $errors[] = array(
                    'index' => $index,
                    'message' => isset($result['message']) ? $result['message'] : 'Errore import.',
                );
                $skipped++;
            }
        }

        $parent_result = array(
            'enabled' => false,
            'linked' => 0,
            'skipped' => 0,
            'errors' => array(),
            'multi_parent' => array(),
        );

        if (!empty($settings['enable_parent_linking'])) {
            $parent_result = $this->assign_parents_second_pass(array_values(array_unique($imported_post_ids)), $settings);
        }

        return array(
            'ok' => true,
            'mode' => 'real_import',
            'processed' => $processed,
            'created' => $created,
            'updated' => $updated,
            'skipped' => $skipped,
            'parent_pass' => $parent_result,
            'errors' => $errors,
        );
    }

    protected function fetch_endpoint_data($endpoint_url) {
        if (empty($endpoint_url)) {
            return array(
                'ok' => false,
                'message' => 'Endpoint URL mancante.',
            );
        }

        $settings = $this->get_settings();
        $headers = array(
            'Accept' => 'application/json',
        );

        if (!empty($settings['auth_bearer_token'])) {
            $headers['Authorization'] = 'Bearer ' . $settings['auth_bearer_token'];
        }

        $response = wp_remote_get($endpoint_url, array(
            'timeout' => 40,
            'headers' => $headers,
            'user-agent' => !empty($settings['request_user_agent']) ? $settings['request_user_agent'] : 'Mozilla/5.0 (compatible; SiteJSONImporter/1.0; +WordPress)',
        ));

        if (is_wp_error($response)) {
            return array(
                'ok' => false,
                'message' => $response->get_error_message(),
            );
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($status < 200 || $status >= 300) {
            return array(
                'ok' => false,
                'message' => 'HTTP status non valido: ' . $status,
            );
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded) || !isset($decoded['data']) || !is_array($decoded['data'])) {
            return array(
                'ok' => false,
                'message' => 'Formato JSON non valido: atteso oggetto con chiave data[].',
            );
        }

        return array(
            'ok' => true,
            'data' => $decoded['data'],
            'meta' => isset($decoded['meta']) && is_array($decoded['meta']) ? $decoded['meta'] : array(),
        );
    }

    protected function import_single_item($item, $settings, $type_map, $acf_map, $acf_path_map, $field_map_v2, $apply_mapping) {
        $source_type = isset($item['type']) ? sanitize_key($item['type']) : '';
        $post_type = $settings['default_post_type'];

        if ($source_type && isset($type_map[$source_type])) {
            $candidate = sanitize_key($type_map[$source_type]);
            if (post_type_exists($candidate)) {
                $post_type = $candidate;
            }
        }

        if (!post_type_exists($post_type)) {
            return array(
                'status' => 'error',
                'message' => 'Post type non esistente: ' . $post_type,
            );
        }

        $uuid = isset($item['uuid']) ? sanitize_text_field((string) $item['uuid']) : '';
        $nid = isset($item['nid']) ? absint($item['nid']) : 0;
        $langcode = isset($item['langcode']) ? sanitize_key($item['langcode']) : '';

        $reference_field = isset($settings['merge_reference_field']) ? sanitize_key($settings['merge_reference_field']) : 'uuid';
        $existing_post_id = $this->find_existing_post_by_reference($item, $reference_field, $post_type);
        if (!$existing_post_id) {
            $existing_post_id = $this->find_existing_post($uuid, $nid, $post_type);
        }

        $title = $this->extract_scalar_value(isset($item['title']) ? $item['title'] : '');
        if ($title === '') {
            $title = sprintf(__('Import item %d', 'site-json-acf-importer'), $nid ?: 0);
        }

        $content = '';
        if (isset($item['body'])) {
            $content = $this->extract_body_value($item['body']);
        }

        $excerpt = '';
        if (isset($item['summary'])) {
            $excerpt = $this->extract_scalar_value($item['summary']);
        }

        $postarr = array(
            'post_type' => $post_type,
            'post_status' => $settings['default_status'],
            'post_title' => wp_strip_all_tags($title),
            'post_content' => $content,
            'post_excerpt' => $excerpt,
        );

        if ($existing_post_id) {
            $postarr['ID'] = $existing_post_id;
            $post_id = wp_update_post($postarr, true);
            $action = 'updated';
        } else {
            $post_id = wp_insert_post($postarr, true);
            $action = 'created';
        }

        if (is_wp_error($post_id)) {
            return array(
                'status' => 'error',
                'message' => $post_id->get_error_message(),
            );
        }

        if ($uuid !== '') {
            update_post_meta($post_id, '_sjai_source_uuid', $uuid);
        }
        if ($nid > 0) {
            update_post_meta($post_id, '_sjai_source_nid', $nid);
        }
        if ($source_type !== '') {
            update_post_meta($post_id, '_sjai_source_type', $source_type);
        }
        if ($langcode !== '') {
            update_post_meta($post_id, '_sjai_source_langcode', $langcode);
        }

        $this->store_source_index_meta($post_id, $item);

        update_post_meta($post_id, '_sjai_raw_item', wp_json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($apply_mapping) {
            if (!empty($field_map_v2[$source_type])) {
                $this->map_fields_v2($post_id, $item, $source_type, $field_map_v2, !empty($settings['import_images']));
            } else {
                $this->map_acf_fields($post_id, $item, $source_type, $acf_map, $acf_path_map, !empty($settings['import_images']));
            }
        }

        return array(
            'status' => $action,
            'post_id' => $post_id,
        );
    }

    protected function store_source_index_meta($post_id, $item) {
        if (!is_array($item)) {
            return;
        }

        foreach ($item as $field_name => $value) {
            $field_key = sanitize_key($field_name);
            if ($field_key === '') {
                continue;
            }

            if (is_string($value) || is_numeric($value)) {
                update_post_meta($post_id, '_sjai_src_' . $field_key, (string) $value);
                continue;
            }

            $scalar = $this->extract_scalar_value($value);
            if ($scalar !== '') {
                update_post_meta($post_id, '_sjai_src_' . $field_key, $scalar);
            }
        }
    }

    protected function find_existing_post($uuid, $nid, $post_type) {
        if ($uuid !== '') {
            $posts = get_posts(array(
                'post_type' => $post_type,
                'post_status' => 'any',
                'fields' => 'ids',
                'posts_per_page' => 1,
                'meta_key' => '_sjai_source_uuid',
                'meta_value' => $uuid,
            ));

            if (!empty($posts)) {
                return (int) $posts[0];
            }
        }

        if ($nid > 0) {
            $posts = get_posts(array(
                'post_type' => $post_type,
                'post_status' => 'any',
                'fields' => 'ids',
                'posts_per_page' => 1,
                'meta_key' => '_sjai_source_nid',
                'meta_value' => $nid,
            ));

            if (!empty($posts)) {
                return (int) $posts[0];
            }
        }

        return 0;
    }

    protected function find_existing_post_by_reference($item, $reference_field, $post_type) {
        if (!is_array($item)) {
            return 0;
        }

        $reference_field = sanitize_key($reference_field);
        if ($reference_field === '') {
            return 0;
        }

        if (!array_key_exists($reference_field, $item)) {
            return 0;
        }

        $reference_value = $this->extract_scalar_value($item[$reference_field]);
        if ($reference_value === '') {
            return 0;
        }

        if ($reference_field === 'uuid') {
            $meta_key = '_sjai_source_uuid';
            $meta_value = sanitize_text_field($reference_value);
        } elseif ($reference_field === 'nid') {
            $meta_key = '_sjai_source_nid';
            $meta_value = (string) absint($reference_value);
        } else {
            $meta_key = '_sjai_src_' . $reference_field;
            $meta_value = (string) $reference_value;
        }

        $posts = get_posts(array(
            'post_type' => $post_type,
            'post_status' => 'any',
            'fields' => 'ids',
            'posts_per_page' => 1,
            'meta_key' => $meta_key,
            'meta_value' => $meta_value,
        ));

        if (empty($posts)) {
            return 0;
        }

        return (int) $posts[0];
    }

    protected function map_acf_fields($post_id, $item, $source_type, $acf_map, $acf_path_map, $import_images) {
        if (empty($source_type) || empty($acf_map[$source_type]) || !is_array($acf_map[$source_type])) {
            return false;
        }

        $post_update = array('ID' => (int) $post_id);
        $has_post_update = false;

        foreach ($acf_map[$source_type] as $source_field => $acf_field_name) {
            if (!array_key_exists($source_field, $item)) {
                continue;
            }

            $value = $item[$source_field];
            $path = '';
            if (isset($acf_path_map[$source_type]) && isset($acf_path_map[$source_type][$source_field]) && is_string($acf_path_map[$source_type][$source_field])) {
                $path = trim($acf_path_map[$source_type][$source_field]);
            }
            if ($path !== '') {
                $value = $this->extract_value_by_path($value, $path);
            }

            $target = is_string($acf_field_name) ? trim($acf_field_name) : '';
            if ($target === '') {
                continue;
            }

            if (strpos($target, 'wp:') === 0) {
                $wp_target = substr($target, 3);
                if ($wp_target === 'post_title') {
                    $post_update['post_title'] = wp_strip_all_tags($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_target === 'post_content') {
                    $post_update['post_content'] = $this->extract_body_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'post_excerpt') {
                    $post_update['post_excerpt'] = $this->extract_scalar_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'post_name') {
                    $post_update['post_name'] = sanitize_title($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_target === 'menu_order') {
                    $post_update['menu_order'] = (int) $this->extract_scalar_value($value);
                    $has_post_update = true;
                } elseif ($wp_target === 'featured_image') {
                    $featured_value = $this->normalize_for_acf($value, $import_images, $post_id);
                    if (is_numeric($featured_value) && (int) $featured_value > 0) {
                        set_post_thumbnail($post_id, (int) $featured_value);
                    }
                }
                continue;
            }

            if (strpos($target, 'yoast:') === 0) {
                $yoast_target = substr($target, 6);
                $yoast_key = $this->get_yoast_meta_key($yoast_target);
                if ($yoast_key !== '') {
                    update_post_meta($post_id, $yoast_key, $this->extract_scalar_value($value));
                }
                continue;
            }

            if (strpos($target, 'acf:') === 0) {
                $acf_field = substr($target, 4);
            } else {
                $acf_field = $target;
            }

            $normalized = $this->normalize_for_acf($value, $import_images, $post_id);
            if (function_exists('update_field')) {
                update_field($acf_field, $normalized, $post_id);
            } else {
                update_post_meta($post_id, $acf_field, $normalized);
            }
        }

        if ($has_post_update) {
            wp_update_post($post_update);
        }

        return true;
    }

    protected function is_assoc_array($value) {
        if (!is_array($value)) {
            return false;
        }

        return array_keys($value) !== range(0, count($value) - 1);
    }

    protected function discover_value_paths($value, $prefix = '', $depth = 0) {
        if (!is_array($value) || $depth > 4) {
            return array();
        }

        $paths = array();

        if ($this->is_assoc_array($value)) {
            foreach ($value as $key => $child) {
                $key = sanitize_key((string) $key);
                if ($key === '') {
                    continue;
                }

                $path = ($prefix === '') ? $key : ($prefix . '.' . $key);
                $paths[] = $path;

                if (is_array($child)) {
                    $paths = array_merge($paths, $this->discover_value_paths($child, $path, $depth + 1));
                }
            }

            return array_values(array_unique($paths));
        }

        if (!array_key_exists(0, $value)) {
            return array();
        }

        $first = $value[0];
        $first_path = ($prefix === '') ? '[0]' : ($prefix . '.[0]');
        $paths[] = $first_path;

        $wildcard_path = ($prefix === '') ? '[*]' : ($prefix . '.[*]');
        $paths[] = $wildcard_path;

        if (is_array($first)) {
            $paths = array_merge($paths, $this->discover_value_paths($first, $first_path, $depth + 1));

            if ($this->is_assoc_array($first)) {
                foreach ($first as $key => $child) {
                    $key = sanitize_key((string) $key);
                    if ($key === '') {
                        continue;
                    }

                    $wildcard_child = $wildcard_path . '.' . $key;
                    $paths[] = $wildcard_child;

                    if (is_array($child)) {
                        $paths = array_merge($paths, $this->discover_value_paths($child, $wildcard_child, $depth + 1));
                    }
                }
            }
        }

        return array_values(array_unique($paths));
    }

    protected function extract_value_by_path($value, $path) {
        $path = is_string($path) ? trim($path) : '';
        if ($path === '') {
            return $value;
        }

        preg_match_all('/(\[\*\]|\[\d+\]|[^\.\[\]]+)/', $path, $matches);
        $segments = isset($matches[0]) && is_array($matches[0]) ? array_values(array_filter($matches[0])) : array();

        if (empty($segments)) {
            return $value;
        }

        return $this->extract_value_by_segments($value, $segments, 0);
    }

    protected function extract_value_by_segments($value, $segments, $index) {
        if (!is_array($segments) || $index >= count($segments)) {
            return $value;
        }

        $segment = $segments[$index];

        if ($segment === '[*]') {
            if (!is_array($value)) {
                return null;
            }

            $out = array();
            foreach ($value as $entry) {
                $extracted = $this->extract_value_by_segments($entry, $segments, $index + 1);
                if ($extracted === null || $extracted === '' || $extracted === array()) {
                    continue;
                }
                $out[] = $extracted;
            }

            return $out;
        }

        if (preg_match('/^\[(\d+)\]$/', $segment, $m)) {
            $offset = (int) $m[1];
            if (!is_array($value) || !array_key_exists($offset, $value)) {
                return null;
            }

            return $this->extract_value_by_segments($value[$offset], $segments, $index + 1);
        }

        $key = sanitize_key($segment);
        if ($key === '' || !is_array($value) || !array_key_exists($key, $value)) {
            return null;
        }

        return $this->extract_value_by_segments($value[$key], $segments, $index + 1);
    }

    protected function get_yoast_meta_key($target) {
        $map = array(
            'seo_title' => '_yoast_wpseo_title',
            'meta_description' => '_yoast_wpseo_metadesc',
            'focus_keyword' => '_yoast_wpseo_focuskw',
            'canonical' => '_yoast_wpseo_canonical',
            'og_title' => '_yoast_wpseo_opengraph-title',
            'og_description' => '_yoast_wpseo_opengraph-description',
            'twitter_title' => '_yoast_wpseo_twitter-title',
            'twitter_description' => '_yoast_wpseo_twitter-description',
        );

        return isset($map[$target]) ? $map[$target] : '';
    }

    // -------------------------------------------------------------------------
    // INVERTED MAP IMPORT LOGIC (field_map_v2)
    // -------------------------------------------------------------------------

    protected function is_acf_image_target($wp_target) {
        if (strpos($wp_target, 'acf:') !== 0) {
            return false;
        }

        if (!function_exists('acf_get_field_groups') || !function_exists('acf_get_fields')) {
            return false;
        }

        $field_name = substr($wp_target, 4);
        $groups = acf_get_field_groups();
        foreach ($groups as $group) {
            $fields = acf_get_fields($group);
            if (!is_array($fields)) {
                continue;
            }
            foreach ($fields as $field) {
                if (isset($field['name']) && $field['name'] === $field_name && isset($field['type'])) {
                    return in_array($field['type'], array('image', 'gallery'), true);
                }
            }
        }

        return false;
    }

    protected function map_fields_v2($post_id, $item, $source_type, $field_map_v2, $import_images) {
        if (empty($field_map_v2[$source_type]) || !is_array($field_map_v2[$source_type])) {
            return false;
        }

        $post_update     = array('ID' => (int) $post_id);
        $has_post_update = false;

        foreach ($field_map_v2[$source_type] as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $wp_target = isset($entry['wp'])  ? trim((string) $entry['wp'])  : '';
            $src_field = isset($entry['src'])  ? sanitize_key($entry['src'])  : '';
            $path      = isset($entry['path']) ? trim((string) $entry['path']) : '';

            if ($wp_target === '' || $src_field === '' || !array_key_exists($src_field, $item)) {
                continue;
            }

            $value = $item[$src_field];
            if ($path !== '') {
                $value = $this->extract_value_by_path($value, $path);
            }

            // IMAGE TARGETS
            if ($wp_target === 'wp:featured_image' || $this->is_acf_image_target($wp_target)) {
                $image_meta = is_array($value) ? $value : array();

                // Override ALT
                $alt_src  = isset($entry['img_alt_src'])    ? sanitize_key($entry['img_alt_src'])        : '';
                $alt_path = isset($entry['img_alt_path'])   ? trim((string) $entry['img_alt_path'])       : '';
                if ($alt_src !== '' && array_key_exists($alt_src, $item)) {
                    $alt_raw = $item[$alt_src];
                    if ($alt_path !== '') {
                        $alt_raw = $this->extract_value_by_path($alt_raw, $alt_path);
                    }
                    $alt_str = $this->extract_scalar_value($alt_raw);
                    if ($alt_str !== '') {
                        $image_meta['alt'] = sanitize_text_field($alt_str);
                    }
                }

                // Override TITLE
                $ttl_src  = isset($entry['img_title_src'])  ? sanitize_key($entry['img_title_src'])      : '';
                $ttl_path = isset($entry['img_title_path']) ? trim((string) $entry['img_title_path'])     : '';
                if ($ttl_src !== '' && array_key_exists($ttl_src, $item)) {
                    $ttl_raw = $item[$ttl_src];
                    if ($ttl_path !== '') {
                        $ttl_raw = $this->extract_value_by_path($ttl_raw, $ttl_path);
                    }
                    $ttl_str = $this->extract_scalar_value($ttl_raw);
                    if ($ttl_str !== '') {
                        $image_meta['title'] = sanitize_text_field($ttl_str);
                    }
                }

                $img_url = '';
                if (is_array($value) && isset($value['url']) && is_string($value['url'])) {
                    $img_url = $value['url'];
                } elseif (is_string($value) && filter_var($value, FILTER_VALIDATE_URL)) {
                    $img_url = $value;
                }

                if ($img_url !== '' && $import_images) {
                    $att_id = $this->sideload_image($img_url, $image_meta, $post_id);
                    if ($att_id > 0) {
                        if ($wp_target === 'wp:featured_image') {
                            set_post_thumbnail($post_id, $att_id);
                        } else {
                            $acf_f = substr($wp_target, 4);
                            if (function_exists('update_field')) {
                                update_field($acf_f, $att_id, $post_id);
                            } else {
                                update_post_meta($post_id, $acf_f, $att_id);
                            }
                        }
                        continue;
                    }
                }

                // Fallback: save URL as text for ACF fields
                if ($img_url !== '' && $wp_target !== 'wp:featured_image') {
                    $acf_f = substr($wp_target, 4);
                    if (function_exists('update_field')) {
                        update_field($acf_f, esc_url_raw($img_url), $post_id);
                    } else {
                        update_post_meta($post_id, $acf_f, esc_url_raw($img_url));
                    }
                }
                continue;
            }

            // WP CORE TARGETS
            if (strpos($wp_target, 'wp:') === 0) {
                $wp_sub = substr($wp_target, 3);
                if ($wp_sub === 'post_title') {
                    $post_update['post_title'] = wp_strip_all_tags($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_sub === 'post_content') {
                    $post_update['post_content'] = $this->extract_body_value($value);
                    $has_post_update = true;
                } elseif ($wp_sub === 'post_excerpt') {
                    $post_update['post_excerpt'] = $this->extract_scalar_value($value);
                    $has_post_update = true;
                } elseif ($wp_sub === 'post_name') {
                    $post_update['post_name'] = sanitize_title($this->extract_scalar_value($value));
                    $has_post_update = true;
                } elseif ($wp_sub === 'menu_order') {
                    $post_update['menu_order'] = (int) $this->extract_scalar_value($value);
                    $has_post_update = true;
                }
                continue;
            }

            // YOAST TARGETS
            if (strpos($wp_target, 'yoast:') === 0) {
                $yoast_key = $this->get_yoast_meta_key(substr($wp_target, 6));
                if ($yoast_key !== '') {
                    update_post_meta($post_id, $yoast_key, $this->extract_scalar_value($value));
                }
                continue;
            }

            // ACF / META TARGETS
            $acf_field = strpos($wp_target, 'acf:') === 0 ? substr($wp_target, 4) : $wp_target;
            $normalized = $this->normalize_for_acf($value, $import_images, $post_id);
            if (function_exists('update_field')) {
                update_field($acf_field, $normalized, $post_id);
            } else {
                update_post_meta($post_id, $acf_field, $normalized);
            }
        }

        if ($has_post_update) {
            wp_update_post($post_update);
        }

        return true;
    }

    protected function normalize_for_acf($value, $import_images, $post_id = 0) {
        if (is_array($value) && isset($value['url']) && is_string($value['url'])) {
            if ($import_images) {
                $attachment_id = $this->sideload_image($value['url'], $value, $post_id);
                if ($attachment_id > 0) {
                    return $attachment_id;
                }
            }
            return esc_url_raw($value['url']);
        }

        if (is_array($value) && isset($value[0]) && is_array($value[0]) && isset($value[0]['url'])) {
            if ($import_images) {
                $ids = array();
                foreach ($value as $entry) {
                    if (!isset($entry['url']) || !is_string($entry['url'])) {
                        continue;
                    }
                    $attachment_id = $this->sideload_image($entry['url'], $entry, $post_id);
                    if ($attachment_id > 0) {
                        $ids[] = $attachment_id;
                    }
                }
                if (!empty($ids)) {
                    return $ids;
                }
            }

            $urls = array();
            foreach ($value as $entry) {
                if (isset($entry['url']) && is_string($entry['url'])) {
                    $urls[] = esc_url_raw($entry['url']);
                }
            }
            return $urls;
        }

        if (is_array($value)) {
            if (isset($value['value']) && count($value) === 1) {
                return $value['value'];
            }

            return $value;
        }

        return $value;
    }

    protected function sideload_image($url, $image_meta = array(), $post_id = 0) {
        if (!is_string($url) || $url === '') {
            return 0;
        }

        if (!function_exists('media_sideload_image')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $temp_file = download_url($url, 30);
        if (is_wp_error($temp_file)) {
            return 0;
        }

        $parsed_url = parse_url($url, PHP_URL_PATH);
        if (!is_string($parsed_url) || $parsed_url === '') {
            $parsed_url = 'imported-image.jpg';
        }

        $file_array = array(
            'name' => wp_basename($parsed_url),
            'tmp_name' => $temp_file,
        );

        $attachment_id = media_handle_sideload($file_array, (int) $post_id);

        if (is_wp_error($attachment_id)) {
            @unlink($temp_file);
            return 0;
        }

        if (is_array($image_meta)) {
            if (!empty($image_meta['alt']) && is_string($image_meta['alt'])) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($image_meta['alt']));
            }

            if (!empty($image_meta['title']) && is_string($image_meta['title'])) {
                wp_update_post(array(
                    'ID' => (int) $attachment_id,
                    'post_title' => sanitize_text_field($image_meta['title']),
                ));
            }
        }

        return (int) $attachment_id;
    }

    protected function get_target_field_options() {
        $options = array(
            'wp:post_title' => 'WordPress: Titolo post (post_title)',
            'wp:post_content' => 'WordPress: Contenuto post (post_content)',
            'wp:post_excerpt' => 'WordPress: Riassunto (post_excerpt)',
            'wp:post_name' => 'WordPress: Slug (post_name)',
            'wp:menu_order' => 'WordPress: Ordinamento menu (menu_order)',
            'wp:featured_image' => 'WordPress: Immagine in evidenza',
            'yoast:seo_title' => 'Yoast: SEO Title',
            'yoast:meta_description' => 'Yoast: Meta Description',
            'yoast:focus_keyword' => 'Yoast: Focus Keyword',
            'yoast:canonical' => 'Yoast: Canonical URL',
            'yoast:og_title' => 'Yoast: OpenGraph Title',
            'yoast:og_description' => 'Yoast: OpenGraph Description',
            'yoast:twitter_title' => 'Yoast: Twitter Title',
            'yoast:twitter_description' => 'Yoast: Twitter Description',
        );

        $acf_fields_found = false;

        if (function_exists('acf_get_field_groups') && function_exists('acf_get_fields')) {
            $groups = acf_get_field_groups();
            foreach ($groups as $group) {
                $fields = acf_get_fields($group);
                if (!is_array($fields)) {
                    continue;
                }

                foreach ($fields as $field) {
                    if (empty($field['name'])) {
                        continue;
                    }

                    $name = (string) $field['name'];
                    $label = !empty($field['label']) ? (string) $field['label'] : $name;
                    $type = !empty($field['type']) ? (string) $field['type'] : 'unknown';
                    $options['acf:' . $name] = 'ACF: ' . $label . ' (' . $name . ' - ' . $type . ')';
                    $acf_fields_found = true;
                }
            }
        }

        if (!$acf_fields_found) {
            $options['acf:manual_field_name'] = __('ACF: nessun campo rilevato (controlla ACF Pro attivo)', 'site-json-acf-importer');
        }

        asort($options);

        return $options;
    }

    // -------------------------------------------------------------------------
    // RENDERING METHODS FOR INVERTED FIELD MAP UI
    // -------------------------------------------------------------------------

    protected function get_acf_image_target_keys() {
        if (!function_exists('acf_get_field_groups') || !function_exists('acf_get_fields')) {
            return array();
        }

        $image_keys = array();
        $groups = acf_get_field_groups();
        foreach ($groups as $group) {
            $fields = acf_get_fields($group);
            if (!is_array($fields)) {
                continue;
            }
            foreach ($fields as $field) {
                if (empty($field['name']) || empty($field['type'])) {
                    continue;
                }
                if (in_array($field['type'], array('image', 'gallery'), true)) {
                    $image_keys[] = 'acf:' . $field['name'];
                }
            }
        }

        return $image_keys;
    }

    protected function render_field_map_section($schema, $settings, $target_options) {
        $acf_image_keys = $this->get_acf_image_target_keys();

        // Export JS data for dynamic rows
        $schema_fields_js = array();
        foreach ($schema['types'] as $type => $fields) {
            $schema_fields_js[sanitize_key($type)] = $fields;
        }

        $target_opts_js = array();
        foreach ($target_options as $k => $v) {
            $is_img = ($k === 'wp:featured_image') || in_array($k, $acf_image_keys, true);
            $target_opts_js[] = array('v' => $k, 'l' => $v, 'img' => $is_img);
        }

        echo '<script>';
        echo 'window.sjaiSchemaFields=' . wp_json_encode($schema_fields_js, JSON_UNESCAPED_UNICODE) . ';';
        echo 'window.sjaiFieldPaths=' . wp_json_encode(isset($schema['field_paths']) ? $schema['field_paths'] : array(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';';
        echo 'window.sjaiTargetOptions=' . wp_json_encode($target_opts_js, JSON_UNESCAPED_UNICODE) . ';';
        echo 'window.sjaiImageTargets=' . wp_json_encode(array_merge(array('wp:featured_image'), $acf_image_keys)) . ';';
        echo '</script>';

        echo '<h3 style="margin-top:20px">' . esc_html__('Mapping campi WordPress &rarr; Drupal', 'site-json-acf-importer') . '</h3>';
        echo '<p class="description">' . esc_html__('Scegli quale campo WordPress popolare e da quale campo Drupal prenderlo. Per i campi immagine puoi configurare anche ALT e TITLE.', 'site-json-acf-importer') . '</p>';

        foreach ($schema['types'] as $source_type => $fields) {
            $type_rows = isset($settings['field_map_v2'][$source_type]) && is_array($settings['field_map_v2'][$source_type])
                ? array_values($settings['field_map_v2'][$source_type])
                : array();

            echo '<h4>' . esc_html(sprintf(__('Tipo: %s', 'site-json-acf-importer'), $source_type)) . '</h4>';
            echo '<table class="widefat sjai-map-table" id="sjai-map-table-' . esc_attr($source_type) . '" data-type="' . esc_attr($source_type) . '" style="max-width:1100px;border-collapse:collapse">';
            echo '<thead><tr>'
                . '<th style="width:30%">' . esc_html__('Campo WordPress (destinazione)', 'site-json-acf-importer') . '</th>'
                . '<th style="width:22%">' . esc_html__('Campo Drupal (sorgente)', 'site-json-acf-importer') . '</th>'
                . '<th style="width:22%">' . esc_html__('Elemento', 'site-json-acf-importer') . '</th>'
                . '<th style="width:15%">' . esc_html__('Anteprima', 'site-json-acf-importer') . '</th>'
                . '<th style="width:11%"></th>'
                . '</tr></thead>';
            echo '<tbody id="sjai-map-tbody-' . esc_attr($source_type) . '">';

            foreach ($type_rows as $row_idx => $row_data) {
                $this->render_field_map_row($source_type, $row_idx, $row_data, $fields, $schema, $target_options, $acf_image_keys);
            }

            echo '</tbody></table>';
            echo '<p><button type="button" class="button sjai-add-row" data-type="' . esc_attr($source_type) . '">+ ' . esc_html__('Aggiungi campo', 'site-json-acf-importer') . '</button></p>';
        }
    }

    protected function render_field_map_row($source_type, $row_idx, $row_data, $fields, $schema, $target_options, $acf_image_keys) {
        $wp_val       = isset($row_data['wp'])             ? (string) $row_data['wp']             : '';
        $src_val      = isset($row_data['src'])            ? (string) $row_data['src']            : '';
        $path_val     = isset($row_data['path'])           ? (string) $row_data['path']           : '';
        $alt_src_val  = isset($row_data['img_alt_src'])    ? (string) $row_data['img_alt_src']    : '';
        $alt_path_val = isset($row_data['img_alt_path'])   ? (string) $row_data['img_alt_path']   : '';
        $ttl_src_val  = isset($row_data['img_title_src'])  ? (string) $row_data['img_title_src']  : '';
        $ttl_path_val = isset($row_data['img_title_path']) ? (string) $row_data['img_title_path'] : '';

        $is_image    = ($wp_val === 'wp:featured_image') || in_array($wp_val, $acf_image_keys, true);
        $field_paths = isset($schema['field_paths'][$source_type][$src_val])     ? $schema['field_paths'][$source_type][$src_val]     : array();
        $alt_paths   = isset($schema['field_paths'][$source_type][$alt_src_val]) ? $schema['field_paths'][$source_type][$alt_src_val] : array();
        $ttl_paths   = isset($schema['field_paths'][$source_type][$ttl_src_val]) ? $schema['field_paths'][$source_type][$ttl_src_val] : array();

        $bn         = 'field_map_v2[' . $source_type . '][' . $row_idx . ']';
        $preview_id = 'sjai-rpath-' . sanitize_html_class($source_type) . '-' . (int) $row_idx;

        // Main row
        echo '<tr class="sjai-map-row" data-row-idx="' . (int) $row_idx . '" data-sjai-type="' . esc_attr($source_type) . '">';

        // WP destination
        echo '<td style="padding:6px 8px"><select name="' . esc_attr($bn . '[wp]') . '" class="sjai-wp-sel" style="width:100%">';
        echo '<option value="">-- ' . esc_html__('Nessuno', 'site-json-acf-importer') . ' --</option>';
        foreach ($target_options as $k => $l) {
            echo '<option value="' . esc_attr($k) . '" ' . selected($wp_val, $k, false) . '>' . esc_html($l) . '</option>';
        }
        echo '</select></td>';

        // Drupal source
        echo '<td style="padding:6px 8px"><select name="' . esc_attr($bn . '[src]') . '" class="sjai-src-sel" style="width:100%">';
        echo '<option value="">--</option>';
        foreach ($fields as $f) {
            echo '<option value="' . esc_attr($f) . '" ' . selected($src_val, $f, false) . '>' . esc_html($f) . '</option>';
        }
        echo '</select></td>';

        // Path
        echo '<td style="padding:6px 8px"><select name="' . esc_attr($bn . '[path]') . '" id="' . esc_attr($preview_id) . '" class="sjai-path-sel" style="width:100%">';
        echo '<option value="">' . esc_html__('Valore completo', 'site-json-acf-importer') . '</option>';
        foreach ($field_paths as $p) {
            echo '<option value="' . esc_attr($p) . '" ' . selected($path_val, $p, false) . '>' . esc_html($p) . '</option>';
        }
        echo '</select></td>';

        // Preview
        echo '<td style="padding:6px 8px">';
        echo '<button type="button" class="button button-small sjai-preview-open-row"'
            . ' data-sjai-type="' . esc_attr($source_type) . '"'
            . ' data-sjai-path-select-id="' . esc_attr($preview_id) . '">'
            . esc_html__('Mostra', 'site-json-acf-importer') . '</button>';
        echo '</td>';

        // Remove
        echo '<td style="padding:6px 8px">';
        echo '<button type="button" class="button button-small sjai-remove-row" style="color:#b32d2e">&times; ' . esc_html__('Rimuovi', 'site-json-acf-importer') . '</button>';
        echo '</td>';

        echo '</tr>';

        // Image sub-row
        echo '<tr class="sjai-img-sub-row" style="' . ($is_image ? '' : 'display:none;') . 'background:#f8f9fa;">';
        echo '<td style="padding:6px 12px;color:#555;font-size:12px;font-style:italic">&#8627; ' . esc_html__('Immagine: ALT e TITLE', 'site-json-acf-importer') . '</td>';
        echo '<td colspan="4" style="padding:6px 8px"><table style="width:100%;font-size:12px;border-collapse:collapse">';
        echo '<tr style="background:#ececec">'
            . '<th style="padding:4px 6px;text-align:left">' . esc_html__('ALT: campo Drupal', 'site-json-acf-importer') . '</th>'
            . '<th style="padding:4px 6px;text-align:left">' . esc_html__('ALT: elemento', 'site-json-acf-importer') . '</th>'
            . '<th style="padding:4px 6px;text-align:left">' . esc_html__('TITLE: campo Drupal', 'site-json-acf-importer') . '</th>'
            . '<th style="padding:4px 6px;text-align:left">' . esc_html__('TITLE: elemento', 'site-json-acf-importer') . '</th>'
            . '</tr><tr>';

        // ALT src
        echo '<td style="padding:4px 6px"><select name="' . esc_attr($bn . '[img_alt_src]') . '" class="sjai-img-alt-src-sel" style="width:100%">';
        echo '<option value="">--</option>';
        foreach ($fields as $f) {
            echo '<option value="' . esc_attr($f) . '" ' . selected($alt_src_val, $f, false) . '>' . esc_html($f) . '</option>';
        }
        echo '</select></td>';

        // ALT path
        echo '<td style="padding:4px 6px"><select name="' . esc_attr($bn . '[img_alt_path]') . '" class="sjai-img-alt-path-sel" style="width:100%">';
        echo '<option value="">' . esc_html__('Valore completo', 'site-json-acf-importer') . '</option>';
        foreach ($alt_paths as $p) {
            echo '<option value="' . esc_attr($p) . '" ' . selected($alt_path_val, $p, false) . '>' . esc_html($p) . '</option>';
        }
        echo '</select></td>';

        // TITLE src
        echo '<td style="padding:4px 6px"><select name="' . esc_attr($bn . '[img_title_src]') . '" class="sjai-img-title-src-sel" style="width:100%">';
        echo '<option value="">--</option>';
        foreach ($fields as $f) {
            echo '<option value="' . esc_attr($f) . '" ' . selected($ttl_src_val, $f, false) . '>' . esc_html($f) . '</option>';
        }
        echo '</select></td>';

        // TITLE path
        echo '<td style="padding:4px 6px"><select name="' . esc_attr($bn . '[img_title_path]') . '" class="sjai-img-title-path-sel" style="width:100%">';
        echo '<option value="">' . esc_html__('Valore completo', 'site-json-acf-importer') . '</option>';
        foreach ($ttl_paths as $p) {
            echo '<option value="' . esc_attr($p) . '" ' . selected($ttl_path_val, $p, false) . '>' . esc_html($p) . '</option>';
        }
        echo '</select></td>';

        echo '</tr></table></td></tr>';
    }

    protected function render_field_map_js() {
        echo '<script>';
        echo '(function(){';
        echo 'var schemaFields=window.sjaiSchemaFields||{};';
        echo 'var fieldPaths=window.sjaiFieldPaths||{};';
        echo 'var targetOpts=window.sjaiTargetOptions||[];';
        echo 'var imageTargets=window.sjaiImageTargets||["wp:featured_image"];';

        echo 'function isImg(v){return imageTargets.indexOf(v)!==-1;}';

        echo 'function makeOpts(arr,selVal,emptyLabel){';
        echo 'var h="<option value=\\"\\">"+(emptyLabel||"--")+"</option>";';
        echo 'arr.forEach(function(o){var v=typeof o==="object"?o.v:String(o),l=typeof o==="object"?o.l:String(o);';
        echo 'h+="<option value=\\""+escH(v)+"\\"" +(v===selVal?" selected":"")+">" +escH(l)+"</option>";});return h;}';

        echo 'function escH(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}';

        echo 'function pathOpts(type,src,sel){var pp=(fieldPaths[type]&&fieldPaths[type][src])?fieldPaths[type][src]:[];';
        echo 'return makeOpts(pp,sel,"Valore completo");}';

        echo 'function srcOpts(type,sel){return makeOpts(schemaFields[type]||[],sel,"--");}';

        echo 'function wpOpts(sel){return makeOpts(targetOpts,sel,"-- Nessuno --");}';

        echo 'function nextIdx(type){var tb=document.getElementById("sjai-map-tbody-"+type);';
        echo 'if(!tb)return 0;var max=-1;';
        echo 'tb.querySelectorAll("tr.sjai-map-row").forEach(function(r){';
        echo 'var i=parseInt(r.getAttribute("data-row-idx"),10);if(!isNaN(i)&&i>max)max=i;});return max+1;}';

        echo 'function makeRowHtml(type,idx){';
        echo 'var bn="field_map_v2["+escH(type)+"]["+idx+"]";';
        echo 'var pid="sjai-rpath-"+escH(type)+"-"+idx;';
        echo 'var m="<tr class=\\"sjai-map-row\\" data-row-idx=\\""+idx+"\\" data-sjai-type=\\""+escH(type)+"\\">"'
            . '+"<td style=\\"padding:6px 8px\\"><select name=\\""+bn+"[wp]\\" class=\\"sjai-wp-sel\\" style=\\"width:100%\\">"+wpOpts("")+"</select></td>"'
            . '+"<td style=\\"padding:6px 8px\\"><select name=\\""+bn+"[src]\\" class=\\"sjai-src-sel\\" style=\\"width:100%\\">"+srcOpts(type,"")+"</select></td>"'
            . '+"<td style=\\"padding:6px 8px\\"><select name=\\""+bn+"[path]\\" id=\\""+pid+"\\" class=\\"sjai-path-sel\\" style=\\"width:100%\\"><option value=\\"\\">Valore completo</option></select></td>"'
            . '+"<td style=\\"padding:6px 8px\\"><button type=\\"button\\" class=\\"button button-small sjai-preview-open-row\\" data-sjai-type=\\""+escH(type)+"\\" data-sjai-path-select-id=\\""+pid+"\\">Mostra</button></td>"'
            . '+"<td style=\\"padding:6px 8px\\"><button type=\\"button\\" class=\\"button button-small sjai-remove-row\\" style=\\"color:#b32d2e\\">&times; Rimuovi</button></td>"'
            . '+"</tr>";';
        echo 'var sub="<tr class=\\"sjai-img-sub-row\\" style=\\"display:none;background:#f8f9fa;\\">\"'
            . '+"<td style=\\"padding:6px 12px;color:#555;font-size:12px;font-style:italic\\">&#8627; Immagine: ALT e TITLE</td>"'
            . '+"<td colspan=\\"4\\" style=\\"padding:6px 8px\\"><table style=\\"width:100%;font-size:12px;border-collapse:collapse\\">"'
            . '+"<tr style=\\"background:#ececec\\"><th style=\\"padding:4px 6px;text-align:left\\">ALT: campo Drupal</th><th style=\\"padding:4px 6px;text-align:left\\">ALT: elemento</th><th style=\\"padding:4px 6px;text-align:left\\">TITLE: campo Drupal</th><th style=\\"padding:4px 6px;text-align:left\\">TITLE: elemento</th></tr>"'
            . '+"<tr>"'
            . '+"<td style=\\"padding:4px 6px\\"><select name=\\""+bn+"[img_alt_src]\\" class=\\"sjai-img-alt-src-sel\\" style=\\"width:100%\\">"+srcOpts(type,"")+"</select></td>"'
            . '+"<td style=\\"padding:4px 6px\\"><select name=\\""+bn+"[img_alt_path]\\" class=\\"sjai-img-alt-path-sel\\" style=\\"width:100%\\"><option value=\\"\\">Valore completo</option></select></td>"'
            . '+"<td style=\\"padding:4px 6px\\"><select name=\\""+bn+"[img_title_src]\\" class=\\"sjai-img-title-src-sel\\" style=\\"width:100%\\">"+srcOpts(type,"")+"</select></td>"'
            . '+"<td style=\\"padding:4px 6px\\"><select name=\\""+bn+"[img_title_path]\\" class=\\"sjai-img-title-path-sel\\" style=\\"width:100%\\"><option value=\\"\\">Valore completo</option></select></td>"'
            . '+"</tr></table></td></tr>";';
        echo 'return m+sub;}';

        echo 'function attachRow(mainRow,type){';
        echo 'var imgSub=mainRow.nextElementSibling;';
        echo 'var wpSel=mainRow.querySelector(".sjai-wp-sel");';
        echo 'var srcSel=mainRow.querySelector(".sjai-src-sel");';
        echo 'var pathSel=mainRow.querySelector(".sjai-path-sel");';
        echo 'var rmBtn=mainRow.querySelector(".sjai-remove-row");';
        echo 'var pvBtn=mainRow.querySelector(".sjai-preview-open-row");';

        echo 'if(wpSel)wpSel.addEventListener("change",function(){if(imgSub)imgSub.style.display=isImg(wpSel.value)?"":"none";});';
        echo 'if(srcSel&&pathSel)srcSel.addEventListener("change",function(){pathSel.innerHTML=pathOpts(type,srcSel.value,"");});';

        echo 'if(imgSub){';
        echo 'var asSel=imgSub.querySelector(".sjai-img-alt-src-sel");';
        echo 'var apSel=imgSub.querySelector(".sjai-img-alt-path-sel");';
        echo 'var tsSel=imgSub.querySelector(".sjai-img-title-src-sel");';
        echo 'var tpSel=imgSub.querySelector(".sjai-img-title-path-sel");';
        echo 'if(asSel&&apSel)asSel.addEventListener("change",function(){apSel.innerHTML=pathOpts(type,asSel.value,"");});';
        echo 'if(tsSel&&tpSel)tsSel.addEventListener("change",function(){tpSel.innerHTML=pathOpts(type,tsSel.value,"");});';
        echo '}';

        echo 'if(rmBtn)rmBtn.addEventListener("click",function(){if(imgSub)imgSub.remove();mainRow.remove();});';

        echo 'if(pvBtn)pvBtn.addEventListener("click",function(){';
        echo 'var t=pvBtn.getAttribute("data-sjai-type")||type;';
        echo 'var f=srcSel?srcSel.value:"";';
        echo 'var pid=pvBtn.getAttribute("data-sjai-path-select-id")||"";';
        echo 'if(window.sjaiOpenPreview)window.sjaiOpenPreview(t,f,pid);';
        echo '});';
        echo '}';

        echo 'document.querySelectorAll("table.sjai-map-table").forEach(function(tbl){';
        echo 'var type=tbl.getAttribute("data-type");';
        echo 'tbl.querySelectorAll("tr.sjai-map-row").forEach(function(r){attachRow(r,type);});});';

        echo 'document.querySelectorAll(".sjai-add-row").forEach(function(btn){';
        echo 'btn.addEventListener("click",function(){';
        echo 'var type=btn.getAttribute("data-type");';
        echo 'var tb=document.getElementById("sjai-map-tbody-"+type);if(!tb)return;';
        echo 'var idx=nextIdx(type);';
        echo 'var tmp=document.createElement("tbody");tmp.innerHTML=makeRowHtml(type,idx);';
        echo 'while(tmp.firstChild){var row=tmp.firstChild;tb.appendChild(row);';
        echo 'if(row.classList&&row.classList.contains("sjai-map-row"))attachRow(row,type);}';
        echo '});});';

        echo '})();';
        echo '</script>';
    }

    protected function extract_body_value($body) {
        if (is_array($body)) {
            if (isset($body['value']) && is_string($body['value'])) {
                return $body['value'];
            }

            if (isset($body[0]) && is_array($body[0]) && isset($body[0]['value']) && is_string($body[0]['value'])) {
                return $body[0]['value'];
            }
        }

        if (is_string($body)) {
            return $body;
        }

        return '';
    }

    protected function extract_all_parent_references($value) {
        $refs = array();

        if (is_null($value) || $value === '' || $value === array()) {
            return $refs;
        }

        // Scalar: single value directly
        if (is_string($value) || is_numeric($value)) {
            $v = trim((string) $value);
            if ($v !== '') {
                $refs[] = $v;
            }
            return $refs;
        }

        if (!is_array($value)) {
            return $refs;
        }

        // Single object: {target_id:X} or {value:X}
        if (isset($value['target_id'])) {
            $refs[] = (string) absint($value['target_id']);
            return $refs;
        }

        if (isset($value['value'])) {
            $v = trim((string) $value['value']);
            if ($v !== '') {
                $refs[] = $v;
            }
            return $refs;
        }

        // Indexed array: [{target_id:X}, {target_id:Y}, ...] or [X, Y, ...]
        foreach ($value as $entry) {
            if (is_array($entry)) {
                if (isset($entry['target_id'])) {
                    $refs[] = (string) absint($entry['target_id']);
                } elseif (isset($entry['value'])) {
                    $v = trim((string) $entry['value']);
                    if ($v !== '') {
                        $refs[] = $v;
                    }
                }
            } elseif (is_string($entry) || is_numeric($entry)) {
                $v = trim((string) $entry);
                if ($v !== '') {
                    $refs[] = $v;
                }
            }
        }

        return array_values(array_unique($refs));
    }

    protected function extract_scalar_value($value) {
        if (is_string($value) || is_numeric($value)) {
            return (string) $value;
        }

        if (is_array($value)) {
            if (isset($value['value']) && (is_string($value['value']) || is_numeric($value['value']))) {
                return (string) $value['value'];
            }
            if (isset($value[0]['value']) && (is_string($value[0]['value']) || is_numeric($value[0]['value']))) {
                return (string) $value[0]['value'];
            }
        }

        return '';
    }
}
